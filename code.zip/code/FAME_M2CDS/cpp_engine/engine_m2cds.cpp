#include "engine.h"
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <chrono>
using std::min;
using std::max;
using std::vector;
static const int DOM_K = 2;
struct FastSet {
    int* arr;
    int* pos;
    int size;
    int cap;
    FastSet() : arr(nullptr), pos(nullptr), size(0), cap(0) {}
    void init(int capacity) {
        cap = capacity;
        size = 0;
        arr = new int[capacity];
        pos = new int[capacity];
        memset(pos, -1, capacity * sizeof(int));
    }
    ~FastSet() { delete[] arr; delete[] pos; }
    void push(int v) {
        if (pos[v] != -1) return;
        arr[size] = v;
        pos[v] = size;
        size++;
    }
    void pop(int v) {
        if (pos[v] == -1) return;
        size--;
        arr[pos[v]] = arr[size];
        pos[arr[size]] = pos[v];
        pos[v] = -1;
    }
    bool contains(int v) const { return pos[v] != -1; }
    void clear() {
        for (int i = 0; i < size; i++) pos[arr[i]] = -1;
        size = 0;
    }
};
struct Engine {
    int n;
    int m;
    int* degree;
    int** adj;
    int* cost;
    int* weight;
    int* num_dmnd;
    int* score;
    int* dmnd_v1;
    int* dmnd_v2;
    FastSet sol_cur;
    FastSet undmnd;
    FastSet redundancy;
    long long sol_cur_cost;
    long long sol_best_cost;
    int* sol_best;
    int sol_best_size;
    long long total_swaps;
    int swap_step;
    int step_unimprove;
    int gap;
    int* freq;
    int* best_member;
    int* flip_count;
    int* in_best_count;
    int* near_best_count;
    int  near_best_samples;
    int  total_improvements;
    int  dnc_calls;
    int  dnc_improvements;
    int  last_dnc_cost;
    int use_stats;
    int use_memory;
    int disable_ale;
    int disable_nsp;
    int disable_car;
    int   nsp_factor;
    int   nsp_kdiv;
    int   car_swap_trigger;
    int   car_eta_base;
    float elite_skip_thr;
    float w_incl;
    float w_red;
    float w_hist;
    float w_repair;
    float w_deg;
    float low_conf;
    float car_clip;
    int   mem_skip_den;
    int* conf;
    int gap_removes_total;
    double time_budget_ms;
    unsigned int rng_state;
    int* bfs_queue;
    int* bfs_vis;
    int  bfs_stamp;
    int fast_rand() {
        rng_state = rng_state * 1103515245u + 12345u;
        return (int)((rng_state >> 16) & 0x7fff);
    }
    int rand_n(int n) {
        return fast_rand() % n;
    }
};
static bool isArticulationPoint(Engine* e, int v) {
    if (e->sol_cur.size <= 1) return true;
    int start = 0;
    for (int i = 0; i < e->sol_cur.size; i++) {
        if (e->sol_cur.arr[i] != v) { start = e->sol_cur.arr[i]; break; }
    }
    if (start == 0) return true;
    int expected = e->sol_cur.size - 1;
    e->bfs_stamp++;
    int stamp = e->bfs_stamp;
    int* visited = e->bfs_vis;
    int* queue = e->bfs_queue;
    int qh = 0, qt = 0;
    int visited_count = 1;
    visited[start] = stamp;
    queue[qt++] = start;
    while (qh < qt) {
        int u = queue[qh++];
        int deg = e->degree[u];
        int* nbrs = e->adj[u];
        for (int j = 0; j < deg; j++) {
            int w = nbrs[j];
            if (w == v) continue;
            if (visited[w] == stamp) continue;
            if (!e->sol_cur.contains(w)) continue;
            visited[w] = stamp;
            queue[qt++] = w;
            visited_count++;
        }
    }
    return visited_count < expected;
}
static bool isSolutionConnected(Engine* e) {
    if (e->sol_cur.size <= 1) return true;
    int start = e->sol_cur.arr[0];
    e->bfs_stamp++;
    int stamp = e->bfs_stamp;
    int* visited = e->bfs_vis;
    int* queue = e->bfs_queue;
    int qh = 0, qt = 0;
    int count = 1;
    visited[start] = stamp;
    queue[qt++] = start;
    while (qh < qt) {
        int u = queue[qh++];
        int deg = e->degree[u];
        int* nbrs = e->adj[u];
        for (int j = 0; j < deg; j++) {
            int w = nbrs[j];
            if (visited[w] == stamp || !e->sol_cur.contains(w)) continue;
            visited[w] = stamp;
            queue[qt++] = w;
            count++;
        }
    }
    return count == e->sol_cur.size;
}
static inline void tryPushRedundancy(Engine* e, int v) {
    if (e->score[v] == 0 && e->sol_cur.contains(v) && !isArticulationPoint(e, v))
        e->redundancy.push(v);
}
static inline void tryPopRedundancy(Engine* e, int v) {
    if (e->redundancy.contains(v) && (e->score[v] != 0 || isArticulationPoint(e, v)))
        e->redundancy.pop(v);
}
static void addVertex(Engine* e, int v_add) {
    if (v_add <= 0 || v_add > e->n) return;
    if (e->sol_cur.contains(v_add)) return;
    int c_add = e->num_dmnd[v_add];
    int w_add = e->weight[v_add];
    int deg = e->degree[v_add];
    int* neighbors = e->adj[v_add];
    for (int i = 0; i < deg; i++) {
        int w = neighbors[i];
        if (e->sol_cur.contains(w)) {
            if (c_add >= 1 && c_add <= DOM_K) {
                e->score[w] += w_add;
            }
        } else {
            if (c_add < DOM_K) {
                e->score[w] -= w_add;
            }
        }
    }
    long long removal_cost = (long long)max(0, DOM_K - c_add) * w_add;
    for (int i = 0; i < deg; i++) {
        int u = neighbors[i];
        e->num_dmnd[u]++;
        int new_c = e->num_dmnd[u];
        int w_u = e->weight[u];
        if (!e->sol_cur.contains(u)) {
            if (new_c < DOM_K) {
                e->score[u] -= w_u;
                removal_cost += w_u;
                if (new_c == 1) {
                    e->dmnd_v1[u] = v_add;
                    e->dmnd_v2[u] = 0;
                }
            } else if (new_c == DOM_K) {
                e->score[u] -= w_u;
                e->dmnd_v2[u] = v_add;
                int deg_u = e->degree[u];
                int* nbrs_u = e->adj[u];
                for (int j = 0; j < deg_u; j++) {
                    int w = nbrs_u[j];
                    if (w == v_add) continue;
                    if (!e->sol_cur.contains(w)) {
                        e->score[w] -= w_u;
                    }
                }
                e->undmnd.pop(u);
                removal_cost += w_u;
            } else if (new_c == DOM_K + 1) {
                int v1 = e->dmnd_v1[u];
                if (v1 != 0) {
                    e->score[v1] += w_u;
                }
                int v2 = e->dmnd_v2[u];
                if (v2 != 0 && v2 != v1) {
                    e->score[v2] += w_u;
                }
            }
        } else {
            int old_c = new_c - 1;
            if (old_c < DOM_K) {
                e->score[u] += w_u;
            }
        }
    }
    e->score[v_add] = -(int)removal_cost;
    e->sol_cur.push(v_add);
    e->sol_cur_cost += e->cost[v_add];
    if (e->undmnd.contains(v_add))
        e->undmnd.pop(v_add);
    if (e->redundancy.contains(v_add))
        e->redundancy.pop(v_add);
    for (int i = 0; i < deg; i++) {
        int w = neighbors[i];
        if (e->sol_cur.contains(w)) {
            if (e->score[w] == 0 && !isArticulationPoint(e, w))
                e->redundancy.push(w);
            else
                e->redundancy.pop(w);
        }
    }
    if (e->score[v_add] == 0 && !isArticulationPoint(e, v_add))
        e->redundancy.push(v_add);
    for (int i = 0; i < deg; i++) {
        int u1 = neighbors[i];
        e->conf[u1] = 1;
        int deg_u1 = e->degree[u1];
        int* nbrs_u1 = e->adj[u1];
        for (int j = 0; j < deg_u1; j++) {
            int u2 = nbrs_u1[j];
            if (u2 == v_add) continue;
            if (e->conf[u2] == 0) e->conf[u2] = 1;
        }
    }
    e->flip_count[v_add]++;
}
static void removeVertex(Engine* e, int v_remove) {
    if (v_remove <= 0 || v_remove > e->n) return;
    if (!e->sol_cur.contains(v_remove)) return;
    if (isArticulationPoint(e, v_remove)) return;
    int c_rem = e->num_dmnd[v_remove];
    int w_rem = e->weight[v_remove];
    e->sol_cur.pop(v_remove);
    e->sol_cur_cost -= e->cost[v_remove];
    if (e->redundancy.contains(v_remove))
        e->redundancy.pop(v_remove);
    int deg = e->degree[v_remove];
    int* neighbors = e->adj[v_remove];
    long long add_score = 0;
    for (int i = 0; i < deg; i++) {
        int u = neighbors[i];
        e->num_dmnd[u]--;
        int new_c = e->num_dmnd[u];
        int w_u = e->weight[u];
        if (!e->sol_cur.contains(u)) {
            if (new_c >= DOM_K) {
                if (new_c == DOM_K) {
                    int found1 = 0, found2 = 0;
                    int deg_u = e->degree[u];
                    int* nbrs_u = e->adj[u];
                    for (int j = 0; j < deg_u; j++) {
                        int w = nbrs_u[j];
                        if (w == v_remove) continue;
                        if (e->sol_cur.contains(w)) {
                            if (found1 == 0) found1 = w;
                            else if (found2 == 0) { found2 = w; break; }
                        }
                    }
                    e->dmnd_v1[u] = found1;
                    e->dmnd_v2[u] = found2;
                    if (found1 != 0) {
                        e->score[found1] -= w_u;
                        if (e->redundancy.contains(found1) &&
                            (e->score[found1] != 0 || isArticulationPoint(e, found1)))
                            e->redundancy.pop(found1);
                    }
                    if (found2 != 0) {
                        e->score[found2] -= w_u;
                        if (e->redundancy.contains(found2) &&
                            (e->score[found2] != 0 || isArticulationPoint(e, found2)))
                            e->redundancy.pop(found2);
                    }
                }
            } else {
                e->score[u] += w_u;
                add_score += w_u;
                if (new_c == DOM_K - 1) {
                    int deg_u = e->degree[u];
                    int* nbrs_u = e->adj[u];
                    for (int j = 0; j < deg_u; j++) {
                        int w = nbrs_u[j];
                        if (w == v_remove) continue;
                        if (!e->sol_cur.contains(w))
                            e->score[w] += w_u;
                    }
                    if (e->dmnd_v1[u] == v_remove)
                        e->dmnd_v1[u] = e->dmnd_v2[u];
                    e->dmnd_v2[u] = 0;
                    e->undmnd.push(u);
                }
            }
        } else {
            if (new_c < DOM_K) {
                e->score[u] -= w_u;
                if (e->redundancy.contains(u) &&
                    (e->score[u] != 0 || isArticulationPoint(e, u)))
                    e->redundancy.pop(u);
            }
        }
    }
    add_score += (long long)max(0, DOM_K - c_rem) * w_rem;
    for (int i = 0; i < deg; i++) {
        int w = neighbors[i];
        if (e->sol_cur.contains(w)) {
            if (c_rem >= 1 && c_rem <= DOM_K) {
                e->score[w] -= w_rem;
                if (e->redundancy.contains(w) &&
                    (e->score[w] != 0 || isArticulationPoint(e, w)))
                    e->redundancy.pop(w);
            }
        } else {
            if (c_rem < DOM_K) {
                e->score[w] += w_rem;
            }
        }
    }
    if (c_rem < DOM_K) {
        e->undmnd.push(v_remove);
    }
    e->score[v_remove] = (int)add_score;
    for (int i = 0; i < deg; i++) {
        int w = neighbors[i];
        if (e->sol_cur.contains(w)) {
            if (e->score[w] == 0 && !isArticulationPoint(e, w))
                e->redundancy.push(w);
            else
                e->redundancy.pop(w);
        }
    }
    {
        int set1_count = 0;
        int* set1 = (deg <= 4096) ? (int*)alloca(deg * sizeof(int)) : new int[deg];
        for (int i = 0; i < deg; i++) {
            int x = neighbors[i];
            if (!e->sol_cur.contains(x) && e->num_dmnd[x] < DOM_K) {
                set1[set1_count++] = x;
            }
        }
        for (int si = 0; si < set1_count; si++) {
            int x = set1[si];
            int deg_x = e->degree[x];
            int* nbrs_x = e->adj[x];
            for (int j = 0; j < deg_x; j++) {
                int y = nbrs_x[j];
                e->conf[y] = 2;
            }
        }
        for (int i = 0; i < deg; i++) {
            int u = neighbors[i];
            if (e->conf[u] == 0) e->conf[u] = 1;
            int deg_u = e->degree[u];
            int* nbrs_u = e->adj[u];
            for (int j = 0; j < deg_u; j++) {
                int w = nbrs_u[j];
                if (w == v_remove) continue;
                if (e->conf[w] == 0) e->conf[w] = 1;
            }
        }
        e->conf[v_remove] = 0;
        if (deg > 4096) delete[] set1;
    }
    e->flip_count[v_remove]++;
}
static void eliminateRedundancy(Engine* e) {
    FastSet& r = e->redundancy;
    r.clear();
    for (int i = 0; i < e->sol_cur.size; i++) {
        int v = e->sol_cur.arr[i];
        if (e->score[v] == 0 && !isArticulationPoint(e, v))
            r.push(v);
    }
    while (r.size > 0) {
        int best = r.arr[0];
        int sample = min(100, r.size);
        for (int i = 1; i < sample; i++) {
            int v = r.arr[i < r.size ? i : e->rand_n(r.size)];
            if (e->cost[v] > e->cost[best]) best = v;
        }
        if (e->score[best] != 0 || isArticulationPoint(e, best)) {
            r.pop(best);
            continue;
        }
        removeVertex(e, best);
    }
}
static int getAddVRand(Engine* e);
static void updateBest(Engine* e);
static inline int compare(int s1, int c1, int s2, int c2);
static const int NSP_THRESHOLD_BASE  = 5000;
static const int NSP_K_MAX  = 5;
static const int NSP_SAMPLE = 50;
static inline float sig_incl(Engine* e, int v) {
    if (!e->use_stats) return 0.5f;
    return (e->total_improvements > 0)
        ? (float)e->in_best_count[v] / (float)e->total_improvements
        : 0.5f;
}
static inline float sig_red(Engine* e, int v) {
    return e->use_stats ? 1.0f - sig_incl(e, v) : 0.5f;
}
static void connectedGreedyConstruct(Engine* e) {
    int root = 1;
    for (int v = 2; v <= e->n; v++) {
        if (e->degree[v] > e->degree[root]) root = v;
    }
    addVertex(e, root);
    int max_iter = e->n * 3;
    while (e->undmnd.size > 0 && max_iter-- > 0) {
        int best_v = 0;
        int best_score = -2000000000;
        for (int i = 0; i < e->sol_cur.size; i++) {
            int u = e->sol_cur.arr[i];
            int deg = e->degree[u];
            int* nbrs = e->adj[u];
            for (int j = 0; j < deg; j++) {
                int w = nbrs[j];
                if (e->sol_cur.contains(w)) continue;
                int rn = compare(best_score, 1, e->score[w], e->cost[w]);
                if (rn < 0) {
                    best_v = w;
                    best_score = e->score[w];
                }
            }
        }
        if (best_v == 0) {
            for (int si = 0; si < e->sol_cur.size; si++) {
                int u = e->sol_cur.arr[si];
                int du = e->degree[u];
                int* nu = e->adj[u];
                for (int j = 0; j < du; j++) {
                    if (!e->sol_cur.contains(nu[j])) {
                        best_v = nu[j];
                        break;
                    }
                }
                if (best_v != 0) break;
            }
            if (best_v == 0) break;
        }
        addVertex(e, best_v);
    }
}
static void solutionPivot(Engine* e) {
    int sol_size = e->sol_cur.size;
    if (sol_size <= 3) return;
    int k = max(1, min(sol_size / e->nsp_kdiv, NSP_K_MAX));
    int sample = min(sol_size, NSP_SAMPLE);
    struct Cand { int v; float score; };
    vector<Cand> remove_cands;
    remove_cands.reserve(sample);
    for (int i = 0; i < sample; i++) {
        int idx = (sample < sol_size) ? e->rand_n(sol_size) : i;
        int v = e->sol_cur.arr[idx];
        if (isArticulationPoint(e, v)) continue;
        float hist = (e->total_improvements > 0)
            ? (float)e->in_best_count[v] / (float)max(1, e->total_improvements)
            : 0.5f;
        float hist_score = e->use_stats ? hist * 2.0f + 0.5f : 0.0f;
        float keep = sig_incl(e, v) * e->w_incl
                   - sig_red(e, v) * e->w_red
                   + hist_score * e->w_hist;
        remove_cands.push_back({v, keep});
    }
    std::sort(remove_cands.begin(), remove_cands.end(),
              [](const Cand& a, const Cand& b){ return a.score < b.score; });
    int removed = 0;
    for (int i = 0; i < (int)remove_cands.size() && removed < k; i++) {
        int v = remove_cands[i].v;
        if (e->sol_cur.contains(v) && e->sol_cur.size > 2 && !isArticulationPoint(e, v)) {
            removeVertex(e, v);
            removed++;
        }
    }
    int max_repair = e->n * 2;
    while (e->undmnd.size > 0 && max_repair-- > 0) {
        int u_rand = e->undmnd.arr[e->rand_n(e->undmnd.size)];
        int best_v = 0;
        float best_s = -1e18f;
        int deg = e->degree[u_rand];
        int* nbrs = e->adj[u_rand];
        for (int j = 0; j < deg; j++) {
            int w = nbrs[j];
            if (e->sol_cur.contains(w)) continue;
            bool adj_sol = false;
            int dw = e->degree[w];
            int* nw = e->adj[w];
            for (int jj = 0; jj < dw; jj++) {
                if (e->sol_cur.contains(nw[jj])) { adj_sol = true; break; }
            }
            if (!adj_sol) continue;
            float s = sig_incl(e, w) * e->w_repair
                    + (float)e->score[w] / (float)max(1, e->cost[w]) * e->w_deg;
            if (s > best_s) { best_s = s; best_v = w; }
        }
        if (best_v > 0 && !e->sol_cur.contains(best_v)) {
            addVertex(e, best_v);
        } else {
            int v_add = 0;
            for (int i = 0; i < e->sol_cur.size; i++) {
                int u = e->sol_cur.arr[i];
                int du = e->degree[u];
                int* nu = e->adj[u];
                for (int j = 0; j < du; j++) {
                    if (!e->sol_cur.contains(nu[j]) && e->score[nu[j]] > 0) {
                        v_add = nu[j];
                        break;
                    }
                }
                if (v_add > 0) break;
            }
            if (v_add > 0) addVertex(e, v_add);
            else break;
        }
    }
    eliminateRedundancy(e);
    if (e->undmnd.size == 0 && isSolutionConnected(e) && e->sol_cur_cost < e->sol_best_cost) {
        updateBest(e);
        e->dnc_improvements++;
    }
    e->dnc_calls++;
}
static void updateBest(Engine* e) {
    if (e->undmnd.size == 0 && e->sol_cur_cost < e->sol_best_cost && isSolutionConnected(e)) {
        e->sol_best_cost = e->sol_cur_cost;
        e->sol_best_size = e->sol_cur.size;
        memcpy(e->sol_best, e->sol_cur.arr, e->sol_cur.size * sizeof(int));
        e->step_unimprove = 0;
        e->total_improvements++;
        memset(e->best_member, 0, (e->n + 1) * sizeof(int));
        for (int i = 0; i < e->sol_cur.size; i++) {
            int v = e->sol_cur.arr[i];
            e->best_member[v] = 1;
            e->in_best_count[v]++;
        }
    }
}
static void sampleNearBest(Engine* e) {
    if (e->undmnd.size == 0 &&
        e->sol_cur_cost <= (long long)(e->sol_best_cost * 1.001) + 1 &&
        isSolutionConnected(e)) {
        e->near_best_samples++;
        for (int i = 0; i < e->sol_cur.size; i++) {
            e->near_best_count[e->sol_cur.arr[i]]++;
        }
    }
}
static inline int compare(int s1, int c1, int s2, int c2) {
    if (c1 == c2) {
        if (s1 > s2) return 1;
        else if (s1 == s2) return 0;
        else return -1;
    }
    long long t1 = (long long)s1 * c2;
    long long t2 = (long long)s2 * c1;
    if (t1 > t2) return 1;
    else if (t1 == t2) return 0;
    else return -1;
}
static int getRemoveVBMS(Engine* e) {
    if (e->sol_cur.size <= 0) return 0;
    int base_bms = max(15, min(e->sol_cur.size / 3, 50));
    int bms_size = min(base_bms, e->sol_cur.size);
    int v_aim = 0;
    auto better_remove = [&](int v_cur, int v_new) -> bool {
        if (isArticulationPoint(e, v_new)) return false;
        if (v_cur != 0 && isArticulationPoint(e, v_cur)) return true;
        int rn = compare(e->score[v_cur], e->cost[v_cur], e->score[v_new], e->cost[v_new]);
        if (rn < 0) return true;
        if (rn == 0) {
            return sig_red(e, v_new) > sig_red(e, v_cur);
        }
        return false;
    };
    if (e->sol_cur.size > bms_size) {
        v_aim = e->sol_cur.arr[e->rand_n(e->sol_cur.size)];
        for (int i = 1; i < bms_size; i++) {
            int v = e->sol_cur.arr[e->rand_n(e->sol_cur.size)];
            if (better_remove(v_aim, v)) v_aim = v;
        }
    } else {
        v_aim = e->sol_cur.arr[0];
        for (int i = 1; i < e->sol_cur.size; i++) {
            int v = e->sol_cur.arr[i];
            if (better_remove(v_aim, v)) v_aim = v;
        }
    }
    if (v_aim != 0 && isArticulationPoint(e, v_aim)) return 0;
    return v_aim;
}
static int getAddVRand(Engine* e) {
    if (e->undmnd.size <= 0) return 0;
    int v = e->undmnd.arr[e->rand_n(e->undmnd.size)];
    int v_aim = 0;
    int v_aim_conf = -1;
    int deg = e->degree[v];
    int* neighbors = e->adj[v];
    auto effective_conf = [&](int u) -> int {
        return e->conf[u];
    };
    for (int i = 0; i < deg; i++) {
        int v_n = neighbors[i];
        if (e->sol_cur.contains(v_n)) continue;
        int cn = effective_conf(v_n);
        if (cn == 0) continue;
        bool adj_sol = false;
        int dn = e->degree[v_n];
        int* nn = e->adj[v_n];
        for (int j = 0; j < dn; j++) {
            if (e->sol_cur.contains(nn[j])) { adj_sol = true; break; }
        }
        if (!adj_sol && e->sol_cur.size > 0) continue;
        if (cn > v_aim_conf) {
            v_aim = v_n;
            v_aim_conf = cn;
        } else if (cn == v_aim_conf) {
            int rn = compare(e->score[v_aim], e->cost[v_aim], e->score[v_n], e->cost[v_n]);
            if (rn < 0) {
                v_aim = v_n;
                v_aim_conf = cn;
            }
        }
    }
    if (!e->sol_cur.contains(v)) {
        bool adj_sol = false;
        int dv = e->degree[v];
        int* nv = e->adj[v];
        for (int j = 0; j < dv; j++) {
            if (e->sol_cur.contains(nv[j])) { adj_sol = true; break; }
        }
        if (adj_sol || e->sol_cur.size == 0) {
            int cv = effective_conf(v);
            if (cv > 0) {
                if (cv > v_aim_conf) {
                    v_aim = v;
                    v_aim_conf = cv;
                } else if (cv == v_aim_conf) {
                    int rn = compare(e->score[v_aim], e->cost[v_aim], e->score[v], e->cost[v]);
                    if (rn < 0) v_aim = v;
                }
            }
        }
    }
    if (v_aim == 0) {
        for (int i = 0; i < e->degree[v]; i++) {
            int v_n = neighbors[i];
            if (e->sol_cur.contains(v_n)) continue;
            bool adj_to_sol = false;
            for (int k = 0; k < e->degree[v_n]; k++) {
                if (e->sol_cur.contains(e->adj[v_n][k])) { adj_to_sol = true; break; }
            }
            if (!adj_to_sol && e->sol_cur.size > 0) continue;
            int rn = compare(e->score[v_aim], e->cost[v_aim], e->score[v_n], e->cost[v_n]);
            if (rn < 0) v_aim = v_n;
        }
        if (v_aim == 0 && !e->sol_cur.contains(v)) {
            bool adj_sol = false;
            for (int j = 0; j < e->degree[v]; j++) {
                if (e->sol_cur.contains(e->adj[v][j])) { adj_sol = true; break; }
            }
            if (adj_sol || e->sol_cur.size == 0) {
                int rn = compare(e->score[v_aim], e->cost[v_aim], e->score[v], e->cost[v]);
                if (rn < 0) v_aim = v;
            }
        }
    }
    return v_aim;
}
static void updateWeight(Engine* e) {
    for (int i = 0; i < e->undmnd.size; i++) {
        int v = e->undmnd.arr[i];
        e->freq[v]++;
        if (e->use_memory && e->total_improvements > 3) {
            float elite_rate = (float)e->in_best_count[v] / (float)max(1, e->total_improvements);
            if (elite_rate > e->elite_skip_thr && e->rand_n(e->mem_skip_den) != 0)
                continue;
        }
        int amp = 1;
        int deficit = max(0, DOM_K - e->num_dmnd[v]);
        e->weight[v] += amp;
        e->score[v] += amp * deficit;
        {
            int deg = e->degree[v];
            int* neighbors = e->adj[v];
            int prop_amp = 1;
            for (int j = 0; j < deg; j++) {
                int w = neighbors[j];
                if (!e->sol_cur.contains(w)) {
                    e->score[w] += prop_amp;
                } else {
                    if (e->num_dmnd[v] + 1 == DOM_K) {
                        e->score[w] -= prop_amp;
                        if (e->redundancy.contains(w) &&
                            (e->score[w] != 0 || isArticulationPoint(e, w)))
                            e->redundancy.pop(w);
                    }
                }
            }
        }
    }
}
static void confidenceAdaptiveReconstruct(Engine* e) {
    int sol_size = e->sol_cur.size;
    if (sol_size <= 3) return;
    struct ConfEntry { int v; float conf; };
    vector<ConfEntry> entries;
    entries.reserve(sol_size);
    int n_low_conf = 0;
    for (int i = 0; i < sol_size; i++) {
        int v = e->sol_cur.arr[i];
        float c = sig_incl(e, v);
        entries.push_back({v, c});
        if (c < e->low_conf) n_low_conf++;
    }
    std::sort(entries.begin(), entries.end(),
              [](const ConfEntry& a, const ConfEntry& b){ return a.conf < b.conf; });
    int base = e->car_eta_base;
    int k_pct = base + (int)((e->car_clip - (float)base) * (float)n_low_conf / (float)max(1, sol_size));
    k_pct = max(base, min((int)e->car_clip, k_pct));
    int k_remove = max(1, sol_size * k_pct / 100);
    int removed = 0;
    for (int i = 0; i < (int)entries.size() && removed < k_remove; i++) {
        int v = entries[i].v;
        if (e->sol_cur.contains(v) && e->sol_cur.size > 2) {
            removeVertex(e, v);
            removed++;
        }
    }
    auto is_adj_to_sol = [&](int v) -> bool {
        if (e->sol_cur.size == 0) return true;
        int dv = e->degree[v];
        int* nv = e->adj[v];
        for (int j = 0; j < dv; j++) {
            if (e->sol_cur.contains(nv[j])) return true;
        }
        return false;
    };
    int max_repair = e->n * 2;
    while (e->undmnd.size > 0 && max_repair-- > 0) {
        int u_rand = e->undmnd.arr[e->rand_n(e->undmnd.size)];
        int best_v = 0;
        float best_s = -1e18f;
        int deg = e->degree[u_rand];
        int* nbrs = e->adj[u_rand];
        for (int j = 0; j < deg; j++) {
            int w = nbrs[j];
            if (e->sol_cur.contains(w)) continue;
            if (!is_adj_to_sol(w)) continue;
            float s = sig_incl(e, w) * e->w_repair
                    + (float)e->score[w] / (float)max(1, e->cost[w]) * e->w_deg;
            if (s > best_s) { best_s = s; best_v = w; }
        }
        if (!e->sol_cur.contains(u_rand) && is_adj_to_sol(u_rand)) {
            float s = sig_incl(e, u_rand) * e->w_repair
                    + (float)e->score[u_rand] / (float)max(1, e->cost[u_rand]) * e->w_deg;
            if (s > best_s) best_v = u_rand;
        }
        if (best_v > 0 && !e->sol_cur.contains(best_v)) {
            addVertex(e, best_v);
        } else {
            int v_add = getAddVRand(e);
            if (v_add > 0 && !e->sol_cur.contains(v_add))
                addVertex(e, v_add);
            else {
                int v_fb = 0;
                for (int si = 0; si < e->sol_cur.size && v_fb == 0; si++) {
                    int su = e->sol_cur.arr[si];
                    int du = e->degree[su];
                    int* nu = e->adj[su];
                    for (int j = 0; j < du; j++) {
                        if (!e->sol_cur.contains(nu[j]) && e->score[nu[j]] > 0) {
                            v_fb = nu[j]; break;
                        }
                    }
                }
                if (v_fb > 0) addVertex(e, v_fb);
                else break;
            }
        }
    }
    eliminateRedundancy(e);
    if (e->undmnd.size == 0 && isSolutionConnected(e) && e->sol_cur_cost < e->sol_best_cost) {
        updateBest(e);
    }
}
extern "C" {
EXPORT EngineHandle engine_create(int n, int* edges, int num_edges, int* costs) {
    Engine* e = new Engine();
    e->n = n;
    e->m = num_edges;
    e->rng_state = 42;
    e->total_swaps = 0;
    e->swap_step = 0;
    e->step_unimprove = 0;
    e->gap = 0;
    e->time_budget_ms = -1.0;
    int cap = n + 1;
    e->degree = new int[cap]();
    e->cost = new int[cap];
    e->weight = new int[cap];
    e->num_dmnd = new int[cap]();
    e->score = new int[cap]();
    e->dmnd_v1 = new int[cap]();
    e->dmnd_v2 = new int[cap]();
    e->freq = new int[cap]();
    e->sol_best = new int[cap];
    e->sol_best_size = 0;
    e->sol_best_cost = (long long)1e18;
    e->sol_cur_cost = 0;
    e->best_member = new int[cap]();
    e->flip_count = new int[cap]();
    e->in_best_count = new int[cap]();
    e->near_best_count = new int[cap]();
    e->near_best_samples = 0;
    e->total_improvements = 0;
    e->dnc_calls = 0;
    e->dnc_improvements = 0;
    e->last_dnc_cost = 0;
    e->use_stats = 1;
    e->use_memory = 1;
    e->disable_ale = 0;
    e->disable_nsp = 0;
    e->disable_car = 0;
    e->nsp_factor = 6;
    e->nsp_kdiv = 25;
    e->car_swap_trigger = 100;
    e->car_eta_base = 10;
    e->elite_skip_thr = 0.6f;
    e->w_incl = 2.5f;
    e->w_red = 1.5f;
    e->w_hist = 0.3f;
    e->w_repair = 2.0f;
    e->w_deg = 0.3f;
    e->low_conf = 0.3f;
    e->car_clip = 25.0f;
    e->mem_skip_den = 3;
    e->conf = new int[cap];
    for (int v = 0; v < cap; v++) e->conf[v] = 1;
    e->bfs_queue = new int[cap];
    e->bfs_vis = new int[cap]();
    e->bfs_stamp = 0;
    e->gap_removes_total = 0;
    for (int v = 1; v <= n; v++) {
        e->cost[v] = 1;
        e->weight[v] = 1;
    }
    for (int i = 0; i < num_edges; i++) {
        int u = edges[2 * i] + 1;
        int v = edges[2 * i + 1] + 1;
        e->degree[u]++;
        e->degree[v]++;
    }
    e->adj = new int*[cap];
    for (int v = 1; v <= n; v++) {
        e->adj[v] = new int[e->degree[v]];
    }
    e->adj[0] = nullptr;
    int* fill = new int[cap]();
    for (int i = 0; i < num_edges; i++) {
        int u = edges[2 * i] + 1;
        int v = edges[2 * i + 1] + 1;
        e->adj[u][fill[u]++] = v;
        e->adj[v][fill[v]++] = u;
    }
    delete[] fill;
    {
        int* seen_stamp = new int[cap]();
        for (int v = 1; v <= n; v++) {
            int w = 0;
            for (int i = 0; i < e->degree[v]; i++) {
                int u = e->adj[v][i];
                if (seen_stamp[u] != v) {
                    seen_stamp[u] = v;
                    e->adj[v][w++] = u;
                }
            }
            e->degree[v] = w;
        }
        delete[] seen_stamp;
    }
    e->sol_cur.init(cap);
    e->undmnd.init(cap);
    e->redundancy.init(cap);
    for (int v = 1; v <= n; v++) {
        e->undmnd.push(v);
        e->score[v] = DOM_K + e->degree[v];
        e->weight[v] = 1;
    }
    e->score[0] = -2000000000;
    e->cost[0] = 1;
    connectedGreedyConstruct(e);
    eliminateRedundancy(e);
    if (e->undmnd.size == 0 && isSolutionConnected(e))
        updateBest(e);
    return (EngineHandle)e;
}
EXPORT void engine_destroy(EngineHandle h) {
    Engine* e = (Engine*)h;
    for (int v = 1; v <= e->n; v++) delete[] e->adj[v];
    delete[] e->adj;
    delete[] e->degree;
    delete[] e->cost;
    delete[] e->weight;
    delete[] e->num_dmnd;
    delete[] e->score;
    delete[] e->dmnd_v1;
    delete[] e->dmnd_v2;
    delete[] e->freq;
    delete[] e->sol_best;
    delete[] e->best_member;
    delete[] e->flip_count;
    delete[] e->in_best_count;
    delete[] e->near_best_count;
    delete[] e->conf;
    delete[] e->bfs_queue;
    delete[] e->bfs_vis;
    delete e;
}
EXPORT void engine_set_solution(EngineHandle h, int* sol, int sol_size) {
    Engine* e = (Engine*)h;
    while (e->sol_cur.size > 0) {
        if (!isArticulationPoint(e, e->sol_cur.arr[0]))
            removeVertex(e, e->sol_cur.arr[0]);
        else if (e->sol_cur.size == 1) {
            int v = e->sol_cur.arr[0];
            e->sol_cur.pop(v);
            e->sol_cur_cost -= e->cost[v];
            break;
        } else {
            bool found = false;
            for (int i = e->sol_cur.size - 1; i >= 0; i--) {
                if (!isArticulationPoint(e, e->sol_cur.arr[i])) {
                    removeVertex(e, e->sol_cur.arr[i]);
                    found = true;
                    break;
                }
            }
            if (!found) break;
        }
    }
    for (int i = 0; i < sol_size; i++) {
        int v = sol[i] + 1;
        addVertex(e, v);
    }
    eliminateRedundancy(e);
    if (isSolutionConnected(e)) updateBest(e);
}
EXPORT void engine_get_solution(EngineHandle h, int* out_sol, int* out_size, int* out_cost) {
    Engine* e = (Engine*)h;
    *out_size = e->sol_cur.size;
    *out_cost = (int)e->sol_cur_cost;
    for (int i = 0; i < e->sol_cur.size; i++)
        out_sol[i] = e->sol_cur.arr[i] - 1;
}
EXPORT long long engine_get_best_cost(EngineHandle h) {
    return ((Engine*)h)->sol_best_cost;
}
EXPORT int engine_get_best_size(EngineHandle h) {
    return ((Engine*)h)->sol_best_size;
}
EXPORT void engine_get_best_solution(EngineHandle h, int* out_sol, int* out_size) {
    Engine* e = (Engine*)h;
    *out_size = e->sol_best_size;
    for (int i = 0; i < e->sol_best_size; i++)
        out_sol[i] = e->sol_best[i] - 1;
}
EXPORT int engine_run_burst(EngineHandle h, float* unused_scores, int steps, int mode) {
    Engine* e = (Engine*)h;
    (void)unused_scores;
    (void)mode;
    int improvements = 0;
    e->score[0] = -2000000000;
    e->cost[0] = 1;
    const bool has_deadline = (e->time_budget_ms > 0.0);
    const auto t0 = std::chrono::steady_clock::now();
    for (int s = 0; s < steps; s++) {
        if (has_deadline) {
            double elapsed_ms = std::chrono::duration<double, std::milli>(
                std::chrono::steady_clock::now() - t0).count();
            if (elapsed_ms >= e->time_budget_ms) break;
        }
        e->step_unimprove++;
        e->total_swaps++;
        int nsp_threshold = max(NSP_THRESHOLD_BASE, e->n * e->nsp_factor);
        if (!(e->disable_ale || e->disable_nsp) && e->step_unimprove > 0 && e->step_unimprove % nsp_threshold == 0) {
            solutionPivot(e);
        }
        if (e->undmnd.size == 0) {
            eliminateRedundancy(e);
            if (e->sol_cur_cost < e->sol_best_cost && isSolutionConnected(e)) {
                updateBest(e);
                improvements++;
                e->step_unimprove = 0;
            }
            sampleNearBest(e);
            int v_rm = getRemoveVBMS(e);
            if (v_rm > 0) removeVertex(e, v_rm);
        }
        {
            int v_rm = getRemoveVBMS(e);
            if (v_rm > 0) removeVertex(e, v_rm);
        }
        {
            int effective_size = e->sol_cur.size;
            int raw_gap = effective_size > 0 ? (int)((e->sol_cur_cost + effective_size - 1) / effective_size) : 0;
            e->gap = raw_gap;
            while (e->sol_cur_cost + e->gap >= e->sol_best_cost) {
                int v_rm = getRemoveVBMS(e);
                if (v_rm <= 0) break;
                removeVertex(e, v_rm);
                e->gap_removes_total++;
                effective_size = e->sol_cur.size;
                raw_gap = effective_size > 0 ? (int)((e->sol_cur_cost + effective_size - 1) / effective_size) : 0;
                e->gap = raw_gap;
            }
        }
        while (e->undmnd.size > 0) {
            int v_add = getAddVRand(e);
            if (v_add <= 0) {
                v_add = e->undmnd.arr[e->rand_n(e->undmnd.size)];
                if (e->sol_cur.contains(v_add)) break;
            }
            int raw_gap_r = e->sol_cur.size > 0 ? (int)((e->sol_cur_cost + e->sol_cur.size - 1) / e->sol_cur.size) : 0;
            e->gap = raw_gap_r;
            if (e->sol_cur_cost + e->cost[v_add] + e->gap <= e->sol_best_cost) {
                addVertex(e, v_add);
            } else {
                int v_rm = getRemoveVBMS(e);
                if (v_rm > 0 && e->score[v_rm] == 0) {
                    removeVertex(e, v_rm);
                    continue;
                }
                if (v_rm > 0 && compare(-e->score[v_rm], e->cost[v_rm],
                                        e->score[v_add], e->cost[v_add]) < 0) {
                    removeVertex(e, v_rm);
                    addVertex(e, v_add);
                    e->total_swaps++;
                    e->swap_step++;
                    if (!(e->disable_ale || e->disable_car) && e->swap_step > e->car_swap_trigger) {
                        confidenceAdaptiveReconstruct(e);
                        e->swap_step = 0;
                    }
                } else {
                    if (e->rand_n(max(1, e->undmnd.size)) == 0) {
                        addVertex(e, v_add);
                    } else {
                        break;
                    }
                }
            }
        }
        updateWeight(e);
    }
    return improvements;
}
EXPORT int engine_run_kick(EngineHandle h, float* unused_scores, int max_steps) {
    return engine_run_burst(h, unused_scores, max_steps, 1);
}
EXPORT void engine_set_time_budget_ms(EngineHandle h, double ms) {
    ((Engine*)h)->time_budget_ms = ms;
}
EXPORT long long engine_get_total_swaps(EngineHandle h) { return ((Engine*)h)->total_swaps; }
EXPORT int engine_get_undmnd_size(EngineHandle h) { return ((Engine*)h)->undmnd.size; }
EXPORT int engine_get_sol_size(EngineHandle h) { return ((Engine*)h)->sol_cur.size; }
EXPORT long long engine_get_sol_cost(EngineHandle h) { return ((Engine*)h)->sol_cur_cost; }
EXPORT void engine_set_seed(EngineHandle h, unsigned int seed) { ((Engine*)h)->rng_state = seed; }
EXPORT void engine_set_guidance_mode(EngineHandle h, int use_stats, int use_memory) {
    Engine* e = (Engine*)h;
    e->use_stats = use_stats;
    e->use_memory = use_memory;
}
EXPORT void engine_set_component_flags(EngineHandle h, int disable_ale, int ale_mask, int _unused) {
    Engine* e = (Engine*)h;
    e->disable_ale = disable_ale;
    e->disable_nsp = (ale_mask & 1) ? 1 : 0;
    e->disable_car = (ale_mask & 2) ? 1 : 0;
    (void)_unused;
}
EXPORT void engine_set_search_params(EngineHandle h,
                                     int nsp_factor, int nsp_kdiv,
                                     int car_swap_trigger, int car_eta_base,
                                     double elite_skip_thr) {
    Engine* e = (Engine*)h;
    if (nsp_factor >= 0) e->nsp_factor = nsp_factor;
    if (nsp_kdiv > 0) e->nsp_kdiv = nsp_kdiv;
    if (car_swap_trigger >= 0) e->car_swap_trigger = car_swap_trigger;
    if (car_eta_base >= 0) e->car_eta_base = car_eta_base;
    if (elite_skip_thr >= 0.0) e->elite_skip_thr = (float)elite_skip_thr;
}
EXPORT void engine_set_coefs(EngineHandle h,
                             double w_incl, double w_red, double w_hist,
                             double w_repair, double w_deg,
                             double low_conf, double car_clip,
                             int mem_skip_den) {
    Engine* e = (Engine*)h;
    if (w_incl >= 0.0) e->w_incl = (float)w_incl;
    if (w_red >= 0.0) e->w_red = (float)w_red;
    if (w_hist >= 0.0) e->w_hist = (float)w_hist;
    if (w_repair >= 0.0) e->w_repair = (float)w_repair;
    if (w_deg >= 0.0) e->w_deg = (float)w_deg;
    if (low_conf >= 0.0) e->low_conf = (float)low_conf;
    if (car_clip >= 0.0) e->car_clip = (float)car_clip;
    if (mem_skip_den >= 2) e->mem_skip_den = mem_skip_den;
}
EXPORT int engine_get_dnc_calls(EngineHandle h) { return ((Engine*)h)->dnc_calls; }
EXPORT int engine_get_total_improvements(EngineHandle h) { return ((Engine*)h)->total_improvements; }
EXPORT void engine_get_diagnostics(EngineHandle h, EngineDiagnostics* out) {
    Engine* e = (Engine*)h;
    out->total_swaps = e->total_swaps;
    out->total_improvements = e->total_improvements;
    out->nsp_calls = e->dnc_calls;
    out->nsp_improvements = e->dnc_improvements;
    out->step_unimprove = e->step_unimprove;
    out->sol_cur_cost = e->sol_cur_cost;
    out->sol_best_cost = e->sol_best_cost;
    out->sol_cur_size = e->sol_cur.size;
    out->sol_best_size = e->sol_best_size;
    out->undmnd_size = e->undmnd.size;
    out->redundancy_size = e->redundancy.size;
    out->gap_removes_total = e->gap_removes_total;
    int c0 = 0, c1 = 0, c2 = 0;
    for (int v = 1; v <= e->n; v++) {
        if (e->conf[v] == 0) c0++;
        else if (e->conf[v] == 1) c1++;
        else c2++;
    }
    out->cc_conf0_count = c0;
    out->cc_conf1_count = c1;
    out->cc_conf2_count = c2;
    int fmax = 0;
    long long fsum = 0;
    for (int v = 1; v <= e->n; v++) {
        if (e->freq[v] > fmax) fmax = e->freq[v];
        fsum += e->freq[v];
    }
    out->freq_max = fmax;
    out->freq_mean = e->n > 0 ? (double)fsum / e->n : 0.0;
    out->nsp_escape_count = 0;
    out->nsp_cur_improved = 0;
    out->nsp_diversity_sum = 0;
}
EXPORT int  engine_get_near_best_samples(EngineHandle h) {
    return ((Engine*)h)->near_best_samples;
}
EXPORT void engine_get_near_best_count(EngineHandle h, int* out, int n) {
    Engine* e = (Engine*)h;
    int copy_n = min(n, e->n);
    for (int i = 0; i < copy_n; i++) {
        out[i] = e->near_best_count[i + 1];
    }
}
}
