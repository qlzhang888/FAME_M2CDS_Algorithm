#include "engine.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
#include <chrono>
static const int BURST_STEPS = 50000;
static const int STAGNATION_LIMIT = 800;
static const double MIN_SOLVE_RATIO = 0.35;
static const double WALL_GRACE_S = 60.0;
struct Graph {
    int n = 0;
    std::vector<int> eu, ev;
};
static bool parse_graph(const char* path, Graph& g) {
    FILE* f = fopen(path, "r");
    if (!f) return false;
    char line[1 << 16];
    bool use_mtx = false;
    bool header_done = false;
    std::vector<int> eu, ev;
    while (fgets(line, sizeof(line), f)) {
        char* s = line;
        while (*s == ' ' || *s == '\t') s++;
        if (*s == '\0' || *s == '\n' || *s == '\r' || *s == '%' || *s == 'c') continue;
        if (!header_done) {
            if (*s == 'p') {
                int m;
                if (sscanf(s, "p edge %d %d", &g.n, &m) != 2 &&
                    sscanf(s, "p %*s %d %d", &g.n, &m) != 2) { fclose(f); return false; }
                use_mtx = false;
                header_done = true;
                continue;
            }
            if (*s == 'e') {
                use_mtx = false;
                header_done = true;
            } else {
                int m;
                if (sscanf(s, "%d %d", &g.n, &m) != 2) { fclose(f); return false; }
                use_mtx = true;
                header_done = true;
                continue;
            }
        }
        int u, v;
        if (use_mtx) {
            if (sscanf(s, "%d %d", &u, &v) != 2) continue;
        } else {
            if (*s != 'e') continue;
            if (sscanf(s, "e %d %d", &u, &v) != 2) continue;
            u -= 1; v -= 1;
        }
        if (u < 0 || v < 0) continue;
        eu.push_back(u);
        ev.push_back(v);
    }
    fclose(f);
    if (!header_done) return false;
    if (g.n <= 0) {
        int mx = 0;
        for (size_t i = 0; i < eu.size(); i++) mx = std::max(mx, std::max(eu[i], ev[i]));
        g.n = mx + 1;
    }
    std::vector<std::pair<int,int>> pairs;
    pairs.reserve(eu.size());
    for (size_t i = 0; i < eu.size(); i++) {
        int a = std::min(eu[i], ev[i]), b = std::max(eu[i], ev[i]);
        if (a != b) pairs.push_back({a, b});
    }
    std::sort(pairs.begin(), pairs.end());
    pairs.erase(std::unique(pairs.begin(), pairs.end()), pairs.end());
    for (auto& p : pairs) { g.eu.push_back(p.first); g.ev.push_back(p.second); }
    return true;
}
static bool verify_solution(const Graph& g, const std::vector<int>& sol) {
    std::vector<char> in_d(g.n, 0);
    for (int v : sol) {
        if (v < 0 || v >= g.n) return false;
        in_d[v] = 1;
    }
    std::vector<std::vector<int>> adj(g.n);
    for (size_t i = 0; i < g.eu.size(); i++) {
        adj[g.eu[i]].push_back(g.ev[i]);
        adj[g.ev[i]].push_back(g.eu[i]);
    }
    for (int v = 0; v < g.n; v++) {
        if (in_d[v]) continue;
        int cnt = 0;
        for (int u : adj[v]) cnt += in_d[u];
        if (cnt < 2) return false;
    }
    if (sol.size() > 1) {
        std::vector<char> vis(g.n, 0);
        std::vector<int> stack = {sol[0]};
        vis[sol[0]] = 1;
        int seen = 1;
        while (!stack.empty()) {
            int u = stack.back(); stack.pop_back();
            for (int w : adj[u]) {
                if (in_d[w] && !vis[w]) { vis[w] = 1; seen++; stack.push_back(w); }
            }
        }
        if (seen != (int)sol.size()) return false;
    }
    return true;
}
int main(int argc, char** argv) {
    if (argc != 5) {
        fprintf(stderr, "Usage: %s <instance_file> <seed> <cutoff_s> <output_file>\n", argv[0]);
        return 2;
    }
    const char* inst_path = argv[1];
    unsigned int seed = (unsigned int)strtoul(argv[2], nullptr, 10);
    double cutoff = strtod(argv[3], nullptr);
    const char* out_path = argv[4];
    if (cutoff <= 0.0) {
        fprintf(stderr, "ERROR: cutoff_s must be positive\n");
        return 2;
    }
    Graph g;
    if (!parse_graph(inst_path, g)) {
        fprintf(stderr, "ERROR: failed to parse instance file: %s\n", inst_path);
        return 1;
    }
    const auto t_start = std::chrono::steady_clock::now();
    auto elapsed_s = [&]() {
        return std::chrono::duration<double>(std::chrono::steady_clock::now() - t_start).count();
    };
    int m = (int)g.eu.size();
    std::vector<int> edges(2 * m);
    for (int i = 0; i < m; i++) { edges[2 * i] = g.eu[i]; edges[2 * i + 1] = g.ev[i]; }
    EngineHandle eng = engine_create(g.n, edges.data(), m, nullptr);
    engine_set_seed(eng, seed);
    {
        static const char* names[7] = {
            "FAME_W_INCL", "FAME_W_RED", "FAME_W_HIST",
            "FAME_W_REPAIR", "FAME_W_DEG", "FAME_LOWCONF", "FAME_CLIP"
        };
        double vals[7] = {-1, -1, -1, -1, -1, -1, -1};
        int mem_den = -1;
        bool any = false;
        for (int i = 0; i < 7; i++) {
            const char* s = getenv(names[i]);
            if (s && *s) { vals[i] = atof(s); any = true; }
        }
        const char* sd = getenv("FAME_MEM_DEN");
        if (sd && *sd) { mem_den = atoi(sd); any = true; }
        if (any) {
            engine_set_coefs(eng, vals[0], vals[1], vals[2], vals[3], vals[4],
                             vals[5], vals[6], mem_den);
        }
    }
    long long best = engine_get_best_cost(eng);
    double t_best = elapsed_s();
    int cycles_no_improve = 0;
    const double wall_deadline = cutoff + WALL_GRACE_S;
    while (true) {
        double el = elapsed_s();
        if (el >= wall_deadline) break;
        if (el >= cutoff) break;
        if (cycles_no_improve >= STAGNATION_LIMIT && el >= cutoff * MIN_SOLVE_RATIO) break;
        double remaining_ms = (cutoff - el) * 1000.0;
        engine_set_time_budget_ms(eng, remaining_ms);
        long long prev = engine_get_best_cost(eng);
        engine_run_burst(eng, nullptr, BURST_STEPS, 1);
        long long cur = engine_get_best_cost(eng);
        if (cur < prev) {
            best = cur;
            t_best = elapsed_s();
            cycles_no_improve = 0;
        } else {
            cycles_no_improve++;
        }
    }
    int sol_size = 0;
    std::vector<int> sol(g.n > 0 ? g.n : 1);
    engine_get_best_solution(eng, sol.data(), &sol_size);
    sol.resize(sol_size);
    bool feasible = (sol_size > 0 && best < (long long)1e17);
    bool legal = feasible && verify_solution(g, sol);
    FILE* out = fopen(out_path, "w");
    if (out) {
        if (feasible) for (int v : sol) fprintf(out, "%d\n", v);
        fclose(out);
    }
    if (feasible) {
        printf("cost %lld\nsize %d\ntime_to_best_s %.3f\nverify %s\n",
               best, sol_size, t_best, legal ? "PASS" : "FAIL");
    } else {
        printf("cost -1\nsize 0\ntime_to_best_s -1\nverify N/A "
               "(no feasible solution within %.0fs)\n", cutoff);
    }
    engine_destroy(eng);
    return (feasible && legal) ? 0 : (feasible ? 3 : 4);
}
