#ifndef M2CDS_CPP_ENGINE_H
#define M2CDS_CPP_ENGINE_H
#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
extern "C" {
#endif
typedef void* EngineHandle;
EXPORT EngineHandle engine_create(int n, int* edges, int num_edges, int* costs);
EXPORT void engine_destroy(EngineHandle h);
EXPORT void engine_set_solution(EngineHandle h, int* sol, int sol_size);
EXPORT void engine_get_solution(EngineHandle h, int* out_sol, int* out_size, int* out_cost);
EXPORT long long engine_get_best_cost(EngineHandle h);
EXPORT int  engine_get_best_size(EngineHandle h);
EXPORT void engine_get_best_solution(EngineHandle h, int* out_sol, int* out_size);
EXPORT int engine_run_burst(EngineHandle h, float* unused_scores, int steps, int mode);
EXPORT int engine_run_kick(EngineHandle h, float* unused_scores, int max_steps);
EXPORT void engine_set_time_budget_ms(EngineHandle h, double ms);
EXPORT long long engine_get_total_swaps(EngineHandle h);
EXPORT int engine_get_undmnd_size(EngineHandle h);
EXPORT int engine_get_sol_size(EngineHandle h);
EXPORT long long engine_get_sol_cost(EngineHandle h);
EXPORT void engine_set_seed(EngineHandle h, unsigned int seed);
EXPORT void engine_set_guidance_mode(EngineHandle h, int use_stats, int use_memory);
EXPORT void engine_set_component_flags(EngineHandle h, int disable_ale, int ale_mask, int _unused);
EXPORT int engine_get_dnc_calls(EngineHandle h);
EXPORT int engine_get_total_improvements(EngineHandle h);
EXPORT void engine_set_search_params(EngineHandle h,
                                     int nsp_factor, int nsp_kdiv,
                                     int car_swap_trigger, int car_eta_base,
                                     double elite_skip_thr);
EXPORT void engine_set_coefs(EngineHandle h,
                             double w_incl, double w_red, double w_hist,
                             double w_repair, double w_deg,
                             double low_conf, double car_clip,
                             int mem_skip_den);
typedef struct {
    long long total_swaps;
    int       total_improvements;
    int       nsp_calls;
    int       nsp_improvements;
    int       step_unimprove;
    long long sol_cur_cost;
    long long sol_best_cost;
    int       sol_cur_size;
    int       sol_best_size;
    int       undmnd_size;
    int       redundancy_size;
    int       cc_conf2_count;
    int       cc_conf1_count;
    int       cc_conf0_count;
    int       gap_removes_total;
    int       freq_max;
    double    freq_mean;
    int       nsp_escape_count;
    int       nsp_cur_improved;
    long long nsp_diversity_sum;
} EngineDiagnostics;
EXPORT void engine_get_diagnostics(EngineHandle h, EngineDiagnostics* out);
EXPORT int  engine_get_near_best_samples(EngineHandle h);
EXPORT void engine_get_near_best_count(EngineHandle h, int* out, int n);
#ifdef __cplusplus
}
#endif
#endif
