import ctypes
import platform
import numpy as np
from pathlib import Path


def _find_library() -> str:
    engine_dir = Path(__file__).parent / "cpp_engine"
    system = platform.system()
    if system == "Linux":
        lib_path = engine_dir / "cpp_engine_m2cds.so"
    elif system == "Darwin":
        lib_path = engine_dir / "cpp_engine_m2cds.dylib"
    else:
        lib_path = engine_dir / "cpp_engine_m2cds.dll"

    if not lib_path.exists():
        raise FileNotFoundError(
            f"C++ M2CDS engine not found at {lib_path}. "
            "Compile engine_m2cds.cpp into a shared library first."
        )
    return str(lib_path)


_lib = None


def _get_lib():
    global _lib
    if _lib is None:
        _lib = ctypes.CDLL(_find_library())
        _setup_prototypes(_lib)
    return _lib


def _setup_prototypes(lib):
    lib.engine_create.argtypes = [
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
    ]
    lib.engine_create.restype = ctypes.c_void_p

    lib.engine_destroy.argtypes = [ctypes.c_void_p]
    lib.engine_destroy.restype = None

    lib.engine_set_solution.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_int),
        ctypes.c_int,
    ]
    lib.engine_set_solution.restype = None

    lib.engine_get_solution.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int),
    ]
    lib.engine_get_solution.restype = None

    lib.engine_get_best_cost.argtypes = [ctypes.c_void_p]
    lib.engine_get_best_cost.restype = ctypes.c_longlong

    lib.engine_get_best_size.argtypes = [ctypes.c_void_p]
    lib.engine_get_best_size.restype = ctypes.c_int

    lib.engine_get_best_solution.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int),
    ]
    lib.engine_get_best_solution.restype = None

    lib.engine_run_burst.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_float),
        ctypes.c_int,
        ctypes.c_int,
    ]
    lib.engine_run_burst.restype = ctypes.c_int

    lib.engine_run_kick.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_float),
        ctypes.c_int,
    ]
    lib.engine_run_kick.restype = ctypes.c_int

    lib.engine_get_total_swaps.argtypes = [ctypes.c_void_p]
    lib.engine_get_total_swaps.restype = ctypes.c_longlong

    lib.engine_get_undmnd_size.argtypes = [ctypes.c_void_p]
    lib.engine_get_undmnd_size.restype = ctypes.c_int

    lib.engine_get_sol_size.argtypes = [ctypes.c_void_p]
    lib.engine_get_sol_size.restype = ctypes.c_int

    lib.engine_get_sol_cost.argtypes = [ctypes.c_void_p]
    lib.engine_get_sol_cost.restype = ctypes.c_longlong

    lib.engine_set_seed.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    lib.engine_set_seed.restype = None

    lib.engine_set_guidance_mode.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    lib.engine_set_guidance_mode.restype = None

    lib.engine_set_component_flags.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    lib.engine_set_component_flags.restype = None

    lib.engine_set_search_params.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_double,
    ]
    lib.engine_set_search_params.restype = None

    lib.engine_set_coefs.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_int,
    ]
    lib.engine_set_coefs.restype = None

    lib.engine_get_dnc_calls.argtypes = [ctypes.c_void_p]
    lib.engine_get_dnc_calls.restype = ctypes.c_int

    lib.engine_get_total_improvements.argtypes = [ctypes.c_void_p]
    lib.engine_get_total_improvements.restype = ctypes.c_int

    lib.engine_get_diagnostics.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.engine_get_diagnostics.restype = None

    lib.engine_get_near_best_samples.argtypes = [ctypes.c_void_p]
    lib.engine_get_near_best_samples.restype = ctypes.c_int

    lib.engine_get_near_best_count.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_int),
        ctypes.c_int,
    ]
    lib.engine_get_near_best_count.restype = None


    lib.engine_set_time_budget_ms.argtypes = [ctypes.c_void_p, ctypes.c_double]
    lib.engine_set_time_budget_ms.restype = None


class EngineDiagnostics(ctypes.Structure):
    _fields_ = [
        ("total_swaps", ctypes.c_longlong),
        ("total_improvements", ctypes.c_int),
        ("nsp_calls", ctypes.c_int),
        ("nsp_improvements", ctypes.c_int),
        ("step_unimprove", ctypes.c_int),
        ("sol_cur_cost", ctypes.c_longlong),
        ("sol_best_cost", ctypes.c_longlong),
        ("sol_cur_size", ctypes.c_int),
        ("sol_best_size", ctypes.c_int),
        ("undmnd_size", ctypes.c_int),
        ("redundancy_size", ctypes.c_int),
        ("cc_conf2_count", ctypes.c_int),
        ("cc_conf1_count", ctypes.c_int),
        ("cc_conf0_count", ctypes.c_int),
        ("gap_removes_total", ctypes.c_int),
        ("freq_max", ctypes.c_int),
        ("freq_mean", ctypes.c_double),
        ("nsp_escape_count", ctypes.c_int),
        ("nsp_cur_improved", ctypes.c_int),
        ("nsp_diversity_sum", ctypes.c_longlong),
    ]


class CppSearchEngine:

    def __init__(self, n: int, edge_index: np.ndarray, costs: np.ndarray = None):
        self.n = n
        lib = _get_lib()


        if edge_index.shape[0] == 2:
            src = edge_index[0].astype(np.int32)
            dst = edge_index[1].astype(np.int32)
        else:
            src = edge_index[:, 0].astype(np.int32)
            dst = edge_index[:, 1].astype(np.int32)









        keep = src != dst
        a = np.minimum(src, dst)[keep]
        b = np.maximum(src, dst)[keep]
        if len(a) > 0:
            pairs = np.stack([a, b], axis=1)






            _, first_idx = np.unique(pairs, axis=0, return_index=True)
            first_idx.sort()
            pairs = pairs[first_idx]
            src_uniq = pairs[:, 0].astype(np.int32)
            dst_uniq = pairs[:, 1].astype(np.int32)
        else:
            src_uniq = a.astype(np.int32)
            dst_uniq = b.astype(np.int32)
        edges_flat = np.empty(len(src_uniq) * 2, dtype=np.int32)
        edges_flat[0::2] = src_uniq
        edges_flat[1::2] = dst_uniq

        num_edges = len(src_uniq)
        edges_ptr = edges_flat.ctypes.data_as(ctypes.POINTER(ctypes.c_int))

        costs_ptr = None
        if costs is not None:
            costs_arr = costs.astype(np.int32)
            costs_ptr = costs_arr.ctypes.data_as(ctypes.POINTER(ctypes.c_int))

        self._handle = lib.engine_create(n, edges_ptr, num_edges, costs_ptr)
        self._lib = lib
        self._buf_sol = (ctypes.c_int * (n + 1))()
        self._buf_size = ctypes.c_int(0)
        self._buf_cost = ctypes.c_int(0)

    def __del__(self):
        if hasattr(self, '_handle') and self._handle:
            self._lib.engine_destroy(self._handle)
            self._handle = None

    def set_seed(self, seed: int):
        self._lib.engine_set_seed(self._handle, ctypes.c_uint(seed))

    def set_solution(self, sol: np.ndarray):
        sol_arr = sol.astype(np.int32)
        sol_ptr = sol_arr.ctypes.data_as(ctypes.POINTER(ctypes.c_int))
        self._lib.engine_set_solution(self._handle, sol_ptr, len(sol_arr))

    def run_burst(self, _unused=None, steps: int = 10000, mode: int = 1) -> int:
        return self._lib.engine_run_burst(self._handle, None, steps, mode)

    def set_time_budget_ms(self, ms: float):
        self._lib.engine_set_time_budget_ms(self._handle, ctypes.c_double(float(ms)))

    def get_best_cost(self) -> int:
        return self._lib.engine_get_best_cost(self._handle)

    def get_best_size(self) -> int:
        return self._lib.engine_get_best_size(self._handle)

    def get_best_solution(self) -> np.ndarray:
        self._lib.engine_get_best_solution(
            self._handle, self._buf_sol, ctypes.byref(self._buf_size)
        )
        size = self._buf_size.value
        return np.array([self._buf_sol[i] for i in range(size)], dtype=np.int32)

    def get_solution(self):
        self._lib.engine_get_solution(
            self._handle, self._buf_sol,
            ctypes.byref(self._buf_size), ctypes.byref(self._buf_cost)
        )
        size = self._buf_size.value
        cost = self._buf_cost.value
        sol = np.array([self._buf_sol[i] for i in range(size)], dtype=np.int32)
        return sol, size, cost

    def get_total_swaps(self) -> int:
        return self._lib.engine_get_total_swaps(self._handle)

    def get_undmnd_size(self) -> int:
        return self._lib.engine_get_undmnd_size(self._handle)

    def get_sol_size(self) -> int:
        return self._lib.engine_get_sol_size(self._handle)

    def get_sol_cost(self) -> int:
        return self._lib.engine_get_sol_cost(self._handle)

    def set_guidance_mode(self, use_stats: bool = True, use_memory: bool = True):
        self._lib.engine_set_guidance_mode(
            self._handle, int(use_stats), int(use_memory))

    def set_component_flags(self, disable_ale: bool = False,
                            disable_nsp: bool = False, disable_car: bool = False,
                            **_kwargs):
        ale_mask = int(disable_nsp) | (int(disable_car) << 1)
        self._lib.engine_set_component_flags(
            self._handle, int(disable_ale), ale_mask, 0)

    def set_search_params(self, nsp_factor: int = -1, nsp_kdiv: int = -1,
                          car_swap_trigger: int = -1, car_eta_base: int = -1,
                          elite_skip_thr: float = -1.0):
        self._lib.engine_set_search_params(
            self._handle, int(nsp_factor), int(nsp_kdiv),
            int(car_swap_trigger), int(car_eta_base), float(elite_skip_thr))

    def set_coefs(self, w_incl: float = -1.0, w_red: float = -1.0,
                  w_hist: float = -1.0, w_repair: float = -1.0,
                  w_deg: float = -1.0, low_conf: float = -1.0,
                  car_clip: float = -1.0, mem_skip_den: int = -1):
        self._lib.engine_set_coefs(
            self._handle, float(w_incl), float(w_red), float(w_hist),
            float(w_repair), float(w_deg), float(low_conf), float(car_clip),
            int(mem_skip_den))

    def get_dnc_calls(self) -> int:
        return self._lib.engine_get_dnc_calls(self._handle)

    def get_total_improvements(self) -> int:
        return self._lib.engine_get_total_improvements(self._handle)

    def get_diagnostics(self) -> dict:
        diag = EngineDiagnostics()
        self._lib.engine_get_diagnostics(self._handle, ctypes.byref(diag))
        return {
            "total_swaps": diag.total_swaps,
            "total_improvements": diag.total_improvements,
            "nsp_calls": diag.nsp_calls,
            "nsp_improvements": diag.nsp_improvements,
            "step_unimprove": diag.step_unimprove,
            "sol_cur_cost": diag.sol_cur_cost,
            "sol_best_cost": diag.sol_best_cost,
            "sol_cur_size": diag.sol_cur_size,
            "sol_best_size": diag.sol_best_size,
            "undmnd_size": diag.undmnd_size,
            "redundancy_size": diag.redundancy_size,
            "cc_conf2_count": diag.cc_conf2_count,
            "cc_conf1_count": diag.cc_conf1_count,
            "cc_conf0_count": diag.cc_conf0_count,
            "gap_removes_total": diag.gap_removes_total,
            "freq_max": diag.freq_max,
            "freq_mean": diag.freq_mean,
            "nsp_escape_count": diag.nsp_escape_count,
            "nsp_cur_improved": diag.nsp_cur_improved,
            "nsp_diversity_sum": diag.nsp_diversity_sum,
        }

    def get_near_best_samples(self) -> int:
        return self._lib.engine_get_near_best_samples(self._handle)

    def get_near_best_count(self) -> np.ndarray:
        buf = (ctypes.c_int * self.n)()
        self._lib.engine_get_near_best_count(self._handle, buf, self.n)
        return np.array([buf[i] for i in range(self.n)], dtype=np.int32)
