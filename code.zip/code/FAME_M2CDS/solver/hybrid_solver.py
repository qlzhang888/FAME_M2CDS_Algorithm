from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Tuple

from .graph_env import GraphEnvironment
from .cpp_bridge import CppSearchEngine
from .diagnostics import DiagnosticsWriter


BURST_STEPS = 50000
_INFEASIBLE_COST = int(9e17)
DIAG_INTERVAL = 50


WALL_GRACE_S = 60.0


STAGNATION_LIMIT = 800
MIN_SOLVE_RATIO = 0.35


class HybridSolverInstance:

    def __init__(self, graph: GraphEnvironment, seed: int, cutoff: float = 600.0):
        self.graph = graph
        self.seed = seed
        self.n = graph.n
        self.cutoff = cutoff

        self.engine = CppSearchEngine(self.n, graph.edge_index, graph.costs)
        self.engine.set_seed(seed)

        self.step = 0
        self.kicks = 0
        self.improvements = 0
        self.best_cost = float('inf')
        self.best_size = 0
        self.best_found_time = 0.0
        self.t_start = 0.0


        self.anytime_trace: List[Tuple[float, int]] = []

        self.diag = {
            "total_swaps": 0,
            "improvements_total": 0,
            "first_impr_time": -1.0,
            "last_impr_time": -1.0,
        }

    def build_initial_solution(self):
        best_cost = self.engine.get_best_cost()
        if 0 < best_cost < _INFEASIBLE_COST and best_cost < self.best_cost:
            self.best_cost = best_cost
            self.best_size = self.engine.get_best_size()

        self.engine.run_burst(steps=min(2000, self.n * 2))
        best_cost = self.engine.get_best_cost()
        if 0 < best_cost < _INFEASIBLE_COST and best_cost < self.best_cost:
            self.best_cost = best_cost
            self.best_size = self.engine.get_best_size()



        if 0 < self.best_cost < _INFEASIBLE_COST:
            self.anytime_trace.append((0.0, int(self.best_cost)))

    def wall_elapsed(self) -> float:
        return time.time() - self.t_start

    def effective_elapsed(self) -> float:


        return self.wall_elapsed()

    def is_time_up(self) -> bool:
        return self.effective_elapsed() >= self.cutoff

    def run_one_cycle(self, _unused=None, burst_steps: int = BURST_STEPS):
        self.step += 1
        self.kicks += 1
        prev_best = self.engine.get_best_cost()

        impr = self.engine.run_burst(None, burst_steps, mode=1)

        new_best = self.engine.get_best_cost()
        if 0 < new_best < _INFEASIBLE_COST and new_best < prev_best:
            self.improvements += impr
            elapsed = self.effective_elapsed()
            if self.best_cost == float('inf') or new_best < self.best_cost:
                self.best_cost = new_best
                self.best_size = self.engine.get_best_size()
                self.best_found_time = elapsed
                self.anytime_trace.append((elapsed, int(new_best)))
                if self.diag["first_impr_time"] < 0:
                    self.diag["first_impr_time"] = elapsed
                self.diag["last_impr_time"] = elapsed
                self.diag["improvements_total"] += impr

        self.diag["total_swaps"] = self.engine.get_total_swaps()

    def get_result(self) -> Dict:
        eff_elapsed = self.effective_elapsed()
        wall_elapsed = self.wall_elapsed()

        cpp_diag = self.engine.get_diagnostics()
        total_swaps = cpp_diag["total_swaps"]
        swaps_per_second = int(total_swaps / max(0.001, eff_elapsed))

        diag = {
            "total_swaps": total_swaps,
            "total_inferences": 0,
            "avg_infer_ms": 0,
            "swaps_per_second": swaps_per_second,
            "nsp_calls": cpp_diag.get("nsp_calls", 0),
            "nsp_improvements": cpp_diag.get("nsp_improvements", 0),
            "gap_removes_total": cpp_diag.get("gap_removes_total", 0),
            "freq_max": cpp_diag.get("freq_max", 0),
            "freq_mean": cpp_diag.get("freq_mean", 0),
            "cc_conf2_count": cpp_diag.get("cc_conf2_count", 0),
            "cc_conf1_count": cpp_diag.get("cc_conf1_count", 0),
            "cc_conf0_count": cpp_diag.get("cc_conf0_count", 0),
            "longest_stagnation": cpp_diag.get("step_unimprove", 0),
            "improvements_total": cpp_diag.get("total_improvements", self.improvements),
            "first_impr_time": self.diag["first_impr_time"],
            "last_impr_time": self.diag["last_impr_time"],
        }

        return {
            "cost": self.best_cost if self.best_cost < float('inf') else -1,
            "size": self.best_size,
            "status": "ok" if self.best_cost < float('inf') else "no_feasible",
            "solve_time_s": self.best_found_time,
            "wall_time_s": wall_elapsed,
            "anytime_trace": self.anytime_trace,
            "queue_wait_s": 0.0,
            "vram_wait_s": 0.0,
            "avg_infer_ms": 0,
            "kicks": self.kicks,
            "improvements": self.improvements,
            "strategy": "hybrid_cpp",
            "diag": diag,
        }


class HybridBatchSolver:

    def __init__(self,
                 disable_ale: bool = False,
                 disable_nsp: bool = False, disable_car: bool = False,
                 disable_stats: bool = False, disable_memory: bool = False,
                 max_batch: int = 48,
                 diag_outdir: str = None, diag_config: str = "full",
                 hard_cutoff: bool = False,
                 search_params: Dict = None,
                 coefs: Dict = None):
        self.disable_ale = disable_ale
        self.disable_nsp = disable_nsp
        self.disable_car = disable_car
        self.disable_stats = disable_stats
        self.disable_memory = disable_memory
        self.max_batch = max_batch
        self.diag_outdir = diag_outdir
        self.diag_config = diag_config
        self.hard_cutoff = hard_cutoff


        self.search_params = dict(search_params or {})



        self.coefs = dict(coefs or {})

    def _solve_one_managed(self, path: str, seed: int, cutoff: float,
                           opt_cost: float = -1) -> Dict:
        try:
            return self._solve_one(path, seed, cutoff, opt_cost=opt_cost)
        except Exception as ex:
            return {
                "cost": -1, "size": -1, "status": f"error:{type(ex).__name__}:{ex}",
                "solve_time_s": 0, "wall_time_s": 0,
                "queue_wait_s": 0, "vram_wait_s": 0,
                "avg_infer_ms": 0, "kicks": 0,
                "improvements": 0, "strategy": "error", "diag": {},
            }

    def _solve_one(self, path: str, seed: int, cutoff: float,
                   opt_cost: float = -1) -> Dict:
        graph = GraphEnvironment.from_dimacs(path)



        t_start = time.time()

        inst = HybridSolverInstance(graph, seed, cutoff)
        inst.t_start = t_start

        inst.engine.set_guidance_mode(
            use_stats=not self.disable_stats,
            use_memory=not self.disable_memory)
        inst.engine.set_component_flags(
            disable_ale=self.disable_ale,
            disable_nsp=self.disable_nsp, disable_car=self.disable_car)
        if self.search_params:
            inst.engine.set_search_params(**self.search_params)
        if self.coefs:
            inst.engine.set_coefs(**self.coefs)

        diag_writer = None
        if self.diag_outdir:
            instance_name = Path(path).stem
            diag_writer = DiagnosticsWriter(
                self.diag_outdir, instance_name, seed,
                opt_cost=opt_cost, config_name=self.diag_config,
            )

        inst.build_initial_solution()










        allow_overtime = not self.hard_cutoff
        m2cds_overtime = False
        wall_deadline = cutoff + WALL_GRACE_S

        cycle = 0
        cycles_without_improvement = 0

        while True:
            elapsed = inst.effective_elapsed()
            over_cutoff = elapsed >= cutoff


            if inst.wall_elapsed() >= wall_deadline:
                break

            if over_cutoff:


                if inst.best_cost < float('inf') or not allow_overtime:
                    break
                m2cds_overtime = True
            elif opt_cost > 0 and inst.best_cost <= opt_cost:
                break

            cycle += 1
            prev_best = inst.best_cost






            if m2cds_overtime:
                inst.engine.set_time_budget_ms(-1.0)
            else:
                inst.engine.set_time_budget_ms(
                    max(0.0, (cutoff - elapsed) * 1000.0))

            inst.run_one_cycle(None, burst_steps=BURST_STEPS)


            if m2cds_overtime and inst.best_cost < float('inf'):
                break


            if inst.best_cost < prev_best:
                cycles_without_improvement = 0
            else:
                cycles_without_improvement += 1




            if (cycles_without_improvement >= STAGNATION_LIMIT and not m2cds_overtime
                    and inst.best_cost < float('inf')):
                if inst.effective_elapsed() >= cutoff * MIN_SOLVE_RATIO:
                    break
                else:
                    cycles_without_improvement = STAGNATION_LIMIT // 2


            if diag_writer and cycle % DIAG_INTERVAL == 0:
                self._write_diagnostics(inst, diag_writer, cycle, prev_best)

        if diag_writer:
            diag_writer.finalize()

        result = inst.get_result()
        if result.get("cost", -1) > 0:
            try:
                result["best_solution"] = inst.engine.get_best_solution().tolist()
            except Exception:
                result["best_solution"] = None
        if m2cds_overtime:
            result["overtime"] = True
        return result

    def _write_diagnostics(self, inst: HybridSolverInstance,
                           diag_writer: DiagnosticsWriter,
                           cycle: int, prev_best: float):
        cpp_diag = inst.engine.get_diagnostics()
        nsp_now = cpp_diag.get("nsp_calls", 0)
        nsp_triggered = 1 if nsp_now > inst.diag.get("_prev_nsp", 0) else 0
        improved = inst.best_cost < prev_best
        op_name = "NSP" if nsp_triggered else "swap"

        step_data = {
            "step": cycle,
            "cost": cpp_diag.get("sol_cur_cost", -1),
            "best_cost": inst.best_cost if inst.best_cost < float('inf') else -1,
            "undmnd_count": cpp_diag.get("undmnd_size", 0),
            "sol_size": cpp_diag.get("sol_cur_size", 0),
            "cpp_burst_ms": 0,
            "cc_conf2_count": cpp_diag.get("cc_conf2_count", 0),
            "cc_conf1_count": cpp_diag.get("cc_conf1_count", 0),
            "cc_conf0_count": cpp_diag.get("cc_conf0_count", 0),
            "ndlo_triggered": nsp_triggered,
            "ndlo_improvement": 1 if improved else 0,
            "operator_used": op_name,
            "operator_reward": 1 if improved else 0,
            "total_swaps": cpp_diag.get("total_swaps", 0),
            "total_improvements": cpp_diag.get("total_improvements", 0),
        }
        inst.diag["_prev_nsp"] = nsp_now
        diag_writer.log_step(step_data)

        delta_cost = prev_best - inst.best_cost if improved else 0
        diag_writer.log_operator(
            op_name, reward=1.0 if improved else 0.0,
            delta_cost=float(delta_cost), time_ms=0, improved=improved)
