from __future__ import annotations

import os
from typing import Optional, Tuple

import numpy as np


class GraphEnvironment:

    __slots__ = ("n", "edge_index", "costs", "degrees")

    def __init__(self, n: int, edge_index: np.ndarray, costs: np.ndarray):
        self.n = n
        self.edge_index = edge_index
        self.costs = costs
        self.degrees = np.bincount(edge_index[1], minlength=n).astype(np.int32)

    @staticmethod
    def from_dimacs(path: str) -> "GraphEnvironment":
        cached = _load_cache(path)
        if cached is not None:
            n, src, dst = cached
        else:
            n, src, dst = _parse_graph_file(path)
            _save_cache(path, n, src, dst)
        edge_index = np.stack([src, dst])
        return GraphEnvironment(n, edge_index, np.ones(n, dtype=np.int32))






def _cache_path(path: str) -> str:
    apath = os.path.abspath(path)
    dataset = os.path.basename(os.path.dirname(apath))
    data_root = os.path.dirname(os.path.dirname(apath))
    return os.path.join(data_root, "_cache", dataset, os.path.basename(apath) + ".npz")


def _load_cache(path: str) -> Optional[Tuple[int, np.ndarray, np.ndarray]]:
    cpath = _cache_path(path)
    try:
        if not os.path.isfile(cpath):
            return None
        if os.path.getmtime(cpath) < os.path.getmtime(path):
            return None
        with np.load(cpath) as z:
            return int(z["n"]), z["src"], z["dst"]
    except Exception:
        return None


def _save_cache(path: str, n: int, src: np.ndarray, dst: np.ndarray) -> None:
    cpath = _cache_path(path)
    tmp = cpath + f".tmp{os.getpid()}.npz"
    try:
        os.makedirs(os.path.dirname(cpath), exist_ok=True)
        np.savez(tmp, n=np.int64(n), src=src, dst=dst)
        os.replace(tmp, cpath)
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass






def _parse_graph_file(path: str) -> Tuple[int, np.ndarray, np.ndarray]:

    use_mtx = False
    n = 0
    skiprows = 0
    with open(path) as f:
        for i, line in enumerate(f):
            s = line.strip()
            if not s or s[0] == '%':
                continue
            tok = s.split()
            t0 = tok[0]
            if t0 == 'p':
                use_mtx = False
                n = int(tok[2])
                skiprows = i + 1
            elif t0 == 'e':
                use_mtx = False
                n = 0
                skiprows = i
            elif t0.lstrip('+-').isdigit():
                use_mtx = True
                n = int(tok[0])
                skiprows = i + 1
            else:
                use_mtx = False
                n = 0
                skiprows = i + 1
            break

    edges = _read_edges(path, use_mtx, skiprows)
    if edges.size == 0:
        a = b = np.empty(0, dtype=np.int64)
    else:
        a = np.ascontiguousarray(edges[:, 0])
        b = np.ascontiguousarray(edges[:, 1])

    m = a.shape[0]
    src = np.empty(2 * m, dtype=np.int64)
    dst = np.empty(2 * m, dtype=np.int64)
    src[0::2] = a
    src[1::2] = b
    dst[0::2] = b
    dst[1::2] = a

    if n == 0 and m > 0:
        n = int(max(a.max(), b.max())) + 1
    return n, src, dst


def _read_edges(path: str, use_mtx: bool, skiprows: int) -> np.ndarray:
    cols = [0, 1] if use_mtx else [1, 2]
    try:
        import pandas as pd
        df = pd.read_csv(path, sep=r"\s+", header=None, comment='%',
                         skiprows=skiprows, usecols=cols, engine='c',
                         dtype=np.int64, na_filter=False)
        e = df.to_numpy(dtype=np.int64)
    except ImportError:
        e = _read_edges_python(path, use_mtx, skiprows)
    if e.ndim != 2 or e.shape[1] != 2:
        e = e.reshape(-1, 2)
    if not use_mtx and e.size:
        e -= 1
    return e


def _read_edges_python(path: str, use_mtx: bool, skiprows: int) -> np.ndarray:
    us, vs = [], []
    ci, cj = (0, 1) if use_mtx else (1, 2)
    with open(path) as f:
        for i, line in enumerate(f):
            if i < skiprows:
                continue
            s = line.strip()
            if not s or s[0] == '%':
                continue
            tok = s.split()
            if len(tok) <= cj:
                continue
            us.append(int(tok[ci]))
            vs.append(int(tok[cj]))
    arr = np.array([us, vs], dtype=np.int64).T
    return arr if arr.size else arr.reshape(-1, 2)
