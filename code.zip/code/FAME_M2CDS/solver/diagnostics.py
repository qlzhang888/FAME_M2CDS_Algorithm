from __future__ import annotations

import csv
import time
from pathlib import Path
from typing import Dict


STEP_CSV_FIELDS = [
    "step", "wall_time_s", "cost", "best_cost", "gap_pct", "undmnd_count", "sol_size",
    "operator_used", "operator_reward",
    "cpp_burst_ms",
    "cc_conf2_count", "cc_conf1_count", "cc_conf0_count",
    "ndlo_triggered", "ndlo_improvement", "ndlo_removed_count",
    "gap_removes_this_step", "swaps_this_step",
    "total_swaps", "total_improvements",
]

OPERATOR_NAMES = ["NSP", "swap"]


class DiagnosticsWriter:

    def __init__(self, outdir: str, instance_name: str, seed: int,
                 opt_cost: float = -1, config_name: str = "full"):
        self.outdir = Path(outdir)
        self.instance_name = instance_name
        self.seed = seed
        self.opt_cost = opt_cost
        self.config_name = config_name
        self.t_start = time.time()


        step_dir = self.outdir / "step_logs"
        step_dir.mkdir(parents=True, exist_ok=True)
        step_path = step_dir / f"{instance_name}_s{seed}_{config_name}.csv"
        self._step_file = open(step_path, "w", newline="", encoding="utf-8")
        self._step_writer = csv.DictWriter(
            self._step_file, fieldnames=STEP_CSV_FIELDS, extrasaction='ignore')
        self._step_writer.writeheader()
        self._step_file.flush()


        self.operator_stats: Dict[str, Dict] = {}
        for name in OPERATOR_NAMES:
            self.operator_stats[name] = {
                "calls": 0,
                "improvements": 0,
                "total_reward": 0.0,
                "total_time_ms": 0.0,
                "total_delta_cost": 0.0,
            }

        self.step_count = 0

    def log_step(self, data: Dict):
        data["wall_time_s"] = round(time.time() - self.t_start, 3)
        if self.opt_cost > 0 and data.get("best_cost", -1) > 0:
            data["gap_pct"] = round(
                100.0 * (data["best_cost"] - self.opt_cost) / self.opt_cost, 4)
        self._step_writer.writerow(data)
        self.step_count += 1
        if self.step_count % 50 == 0:
            self._step_file.flush()

    def log_operator(self, name: str, reward: float, delta_cost: float,
                     time_ms: float, improved: bool):
        if name not in self.operator_stats:
            self.operator_stats[name] = {
                "calls": 0, "improvements": 0,
                "total_reward": 0.0, "total_time_ms": 0.0,
                "total_delta_cost": 0.0,
            }
        s = self.operator_stats[name]
        s["calls"] += 1
        s["total_reward"] += reward
        s["total_time_ms"] += time_ms
        s["total_delta_cost"] += delta_cost
        if improved:
            s["improvements"] += 1

    def finalize(self) -> Dict:
        self._step_file.close()


        op_path = self.outdir / "operator_summary.csv"
        write_header = not op_path.exists()
        with open(op_path, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if write_header:
                w.writerow(["instance", "seed", "config", "operator",
                            "calls", "improvements", "avg_reward",
                            "avg_time_ms", "avg_delta_cost", "improvement_rate"])
            for name, s in self.operator_stats.items():
                calls = max(1, s["calls"])
                w.writerow([
                    self.instance_name, self.seed, self.config_name, name,
                    s["calls"], s["improvements"],
                    round(s["total_reward"] / calls, 4),
                    round(s["total_time_ms"] / calls, 2),
                    round(s["total_delta_cost"] / calls, 1),
                    round(s["improvements"] / calls, 4) if s["calls"] > 0 else 0,
                ])

        return {
            "total_steps_logged": self.step_count,
            "operator_stats": self.operator_stats,
        }
