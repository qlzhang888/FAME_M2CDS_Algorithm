from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from threading import Lock, BoundedSemaphore
from typing import Dict, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from solver.hybrid_solver import HybridBatchSolver


def load_optima(optima_path: str) -> Dict[str, Dict]:
    if not optima_path or not os.path.isfile(optima_path):
        return {}
    if optima_path.endswith(".csv"):
        optima = {}
        with open(optima_path, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                ref_cost_str = row.get("ref_cost", "").strip()
                if not ref_cost_str:
                    continue
                key = f"{row['dataset']}/{row['instance']}"
                optima[key] = {
                    "opt_cost": float(ref_cost_str),
                    "status": row.get("status", "N/A"),
                    "time_s": float(row.get("solve_time", -1) or -1),
                }
        return optima
    with open(optima_path, "r") as f:
        data = json.load(f)
    if isinstance(data, dict):
        return data
    optima = {}
    for entry in data:
        key = f"{entry['dataset']}/{entry['instance']}"
        optima[key] = entry
    return optima


def estimate_graph_size(path: str) -> int:
    name = Path(path).stem
    for part in name.split("E"):
        for sub in part.split("V"):
            if sub.isdigit():
                return int(sub)
    return 1000


def parse_dimacs_header(path: str):
    try:
        with open(path, "r") as f:
            for line in f:
                s = line.strip()
                if not s or s[0] in ('%', 'c'):
                    continue
                tok = s.split()
                if tok[0] == "p":
                    return int(tok[2]), int(tok[3])
                if tok[0].lstrip('+-').isdigit():
                    n = int(tok[0])
                    e = int(tok[2]) if len(tok) >= 3 else (int(tok[1]) if len(tok) >= 2 else 0)
                    return n, e
                break
    except Exception:
        pass
    return 500, 3000


def compute_adaptive_cutoff(n_vertices: int, n_edges: int,
                            dataset: str, max_cutoff: float) -> float:
    if n_vertices <= 200:
        base = 30.0
    elif n_vertices <= 500 and n_edges <= 5000:
        base = 60.0
    elif n_vertices <= 500:
        base = 120.0
    elif n_vertices <= 800 and n_edges <= 10000:
        base = 120.0
    elif n_vertices <= 800:
        base = 180.0
    elif n_vertices <= 1000 and n_edges <= 20000:
        base = 180.0
    elif n_vertices <= 1000:
        base = 300.0
    else:
        base = 300.0

    if dataset.upper() in ("DIMACS", "BHOSLIB"):
        base *= 2.0

    base *= 2.0

    return min(max(base, 10.0), max_cutoff)


def run_benchmark(args):
    print(f"M2CDS FAME Benchmark (pure heuristic)", flush=True)
    print(f"  Problem: {args.problem}", flush=True)

    tasks_raw = []
    with open(args.task_csv, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            tasks_raw.append(row)
    print(f"  Tasks: {len(tasks_raw)}", flush=True)

    optima = load_optima(args.optima) if args.optima else {}
    print(f"  Loaded {len(optima)} optima", flush=True)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    results_csv = outdir / "results.csv"
    diag_csv = outdir / "diag.csv"
    sol_dir = outdir / "solutions"
    sol_dir.mkdir(parents=True, exist_ok=True)

    disable_ale = getattr(args, 'disable_ale', False)
    disable_nsp = getattr(args, 'disable_nsp', False)
    disable_car = getattr(args, 'disable_car', False)
    disable_stats = getattr(args, 'disable_stats', False)
    disable_memory = getattr(args, 'disable_memory', False)

    if disable_stats and disable_ale and disable_memory:
        config_name = "No-FAME"
    elif disable_ale:
        config_name = "No-ALE"
    elif disable_nsp:
        config_name = "No-NSP"
    elif disable_car:
        config_name = "No-CAR"
    elif disable_stats:
        config_name = "No-Stats"
    elif disable_memory:
        config_name = "No-Memory"
    else:
        config_name = "FULL"

    search_params = {
        "nsp_factor": args.nsp_factor,
        "nsp_kdiv": args.nsp_kdiv,
        "car_swap_trigger": args.car_swap_trigger,
        "car_eta_base": args.car_eta_base,
        "elite_skip_thr": args.elite_skip_threshold,
    }
    coefs = {
        "w_incl": args.w_incl,
        "w_red": args.w_red,
        "w_hist": args.w_hist,
        "w_repair": args.w_repair,
        "w_deg": args.w_deg,
        "low_conf": args.low_conf,
        "car_clip": args.car_clip,
        "mem_skip_den": args.mem_skip_den,
    }

    print(f"  Config: {config_name}", flush=True)


    use_adaptive = getattr(args, "adaptive", False)
    all_tasks: List[Dict] = []
    for row in tasks_raw:
        dataset = row["dataset"]
        instance = row["instance"]
        seed = int(row["seed"])
        graph_path = os.path.join(args.data_root, dataset, instance)

        opt_key = f"{dataset}/{instance}"
        opt_info = optima.get(opt_key, {})
        opt_cost = opt_info.get("opt_cost", opt_info.get("cost", -1))
        cplex_time = opt_info.get("time_s", -1)
        cplex_status = opt_info.get("status", "N/A")

        nv, ne = parse_dimacs_header(graph_path)
        if use_adaptive:
            inst_cutoff = compute_adaptive_cutoff(nv, ne, dataset, args.cutoff)
        else:
            inst_cutoff = args.cutoff



        target_cost = opt_cost if str(cplex_status).lower() == "optimal" else -1

        all_tasks.append({
            "path": graph_path, "seed": seed, "opt_cost": opt_cost,
            "target_cost": target_cost,
            "dataset": dataset, "instance": instance,
            "cplex_time": cplex_time, "cplex_status": cplex_status,
            "n_vertices": nv, "n_edges": ne, "cutoff": inst_cutoff,
        })

    all_tasks.sort(key=lambda t: t["n_vertices"])

    solver = HybridBatchSolver(
        disable_ale=disable_ale,
        disable_nsp=disable_nsp, disable_car=disable_car,
        disable_stats=disable_stats, disable_memory=disable_memory,
        max_batch=args.max_batch,
        diag_outdir=str(outdir), diag_config=config_name,
        hard_cutoff=getattr(args, 'hard_cutoff', False),
        search_params=search_params,
        coefs=coefs,
    )

    max_workers = min(args.max_batch, len(all_tasks), os.cpu_count() or 4)

    print(f"  Max parallel threads: {max_workers}", flush=True)
    n_big = sum(1 for t in all_tasks if t["n_vertices"] >= args.big_nodes)
    if n_big:
        print(f"  Big instances (n>={args.big_nodes}): {n_big} tasks run LAST, "
              f"max {args.big_batch} concurrent (memory guard)", flush=True)
    if use_adaptive:
        cutoffs = [t["cutoff"] for t in all_tasks]
        print(f"  Cutoff: ADAPTIVE (max={args.cutoff}s, "
              f"range=[{min(cutoffs):.0f}s, {max(cutoffs):.0f}s])", flush=True)
    else:
        print(f"  Cutoff: {args.cutoff}s (hard)", flush=True)


    result_fields = [
        "dataset", "instance", "seed", "cost", "opt_cost", "gap_pct",
        "size", "status", "solve_time_s", "wall_time_s", "queue_wait_s",
        "vram_wait_s", "avg_infer_ms", "kicks",
        "improvements", "strategy", "cutoff_s", "cplex_time_s", "cplex_status",
        "overtime",
    ]
    diag_fields = [
        "dataset", "instance", "seed", "best_cost", "opt_cost", "gap_pct", "solve_time_s",
        "total_swaps", "total_inferences", "total_kicks",
        "avg_infer_ms", "swaps_per_second",
        "nsp_calls", "nsp_improvements", "gap_removes_total",
        "freq_max", "freq_mean",
        "cc_conf2_count", "cc_conf1_count", "cc_conf0_count",
        "longest_stagnation", "improvements_total",
        "first_impr_time", "last_impr_time",
    ]

    f_results = open(results_csv, "w", newline="", encoding="utf-8")
    f_diag = open(diag_csv, "w", newline="", encoding="utf-8")
    w_results = csv.DictWriter(f_results, fieldnames=result_fields, extrasaction='ignore')
    w_diag = csv.DictWriter(f_diag, fieldnames=diag_fields, extrasaction='ignore')
    w_results.writeheader()
    w_diag.writeheader()
    f_results.flush()
    f_diag.flush()

    f_anytime = None
    w_anytime = None
    if getattr(args, "anytime", False):
        f_anytime = open(outdir / "anytime.csv", "w", newline="", encoding="utf-8")
        w_anytime = csv.writer(f_anytime)
        w_anytime.writerow(["dataset", "instance", "seed", "effective_time_s", "cost"])
        f_anytime.flush()

    total_tasks = len(all_tasks)
    completed = 0
    exact_hits = 0
    beats_approx = 0
    csv_lock = Lock()
    t_start = time.time()

    print(f"\nRunning: {total_tasks} tasks (cross-instance parallel, {max_workers} threads)",
          flush=True)
    print("=" * 70, flush=True)


    max_cutoff_used = max(t["cutoff"] for t in all_tasks) if all_tasks else args.cutoff

    big_sem = BoundedSemaphore(args.big_batch)

    def _run_task(task):




        if task["n_vertices"] >= args.big_nodes:
            with big_sem:
                return solver._solve_one_managed(
                    task["path"], int(task["seed"]), task["cutoff"],
                    opt_cost=float(task.get("target_cost", -1)))
        return solver._solve_one_managed(
            task["path"], int(task["seed"]), task["cutoff"],
            opt_cost=float(task.get("target_cost", -1)))

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_to_task = {}
        for task in all_tasks:
            fut = pool.submit(_run_task, task)
            future_to_task[fut] = task

        for fut in as_completed(future_to_task):
            task = future_to_task[fut]
            dataset = task["dataset"]
            instance = task["instance"]
            seed = task["seed"]
            opt_cost = task["opt_cost"]

            try:
                result = fut.result(timeout=max_cutoff_used * 5)
            except Exception as e:
                import traceback
                print(f"  [ERROR] {dataset}/{instance}_s{seed}: {e}", flush=True)
                traceback.print_exc()
                result = {
                    "cost": -1, "size": -1, "status": f"error:{e}",
                    "solve_time_s": 0, "wall_time_s": 0,
                    "queue_wait_s": 0, "vram_wait_s": 0,
                    "avg_infer_ms": 0, "kicks": 0,
                    "improvements": 0, "strategy": "error", "diag": {},
                }

            cost = result.get("cost", -1)
            cplex_st = task["cplex_status"]
            is_exact = (cplex_st.lower() == "optimal") if cplex_st else False

            if cost > 0 and opt_cost > 0:
                gap = round(100.0 * (cost - opt_cost) / opt_cost, 3)
            else:
                gap = -1

            is_hit = (is_exact and cost > 0 and opt_cost > 0
                      and abs(cost - opt_cost) < 0.5)
            is_beat = (not is_exact and cost > 0 and opt_cost > 0
                       and cost <= opt_cost + 0.5)

            is_overtime = result.get("overtime", False)

            best_sol = result.get("best_solution")
            if best_sol:
                safe_inst = str(instance).replace("/", "_").replace("\\", "_")
                sol_path = sol_dir / f"{dataset}_{safe_inst}_seed{seed}.txt"
                try:
                    with open(sol_path, "w") as sf:
                        sf.write("\n".join(str(int(v)) for v in best_sol))
                except Exception as e:
                    print(f"  [WARN] failed to write solution {sol_path}: {e}", flush=True)

            row = {
                "dataset": dataset, "instance": instance, "seed": seed,
                "cost": cost, "opt_cost": opt_cost, "gap_pct": gap,
                "size": result.get("size", -1),
                "status": result.get("status", "error"),
                "solve_time_s": result.get("solve_time_s", 0),
                "wall_time_s": result.get("wall_time_s", 0),
                "queue_wait_s": round(result.get("queue_wait_s", 0), 3),
                "vram_wait_s": round(result.get("vram_wait_s", 0), 3),
                "avg_infer_ms": round(result.get("avg_infer_ms", 0), 1),
                "kicks": result.get("kicks", 0),
                "improvements": result.get("improvements", 0),
                "strategy": result.get("strategy", "unknown"),
                "cutoff_s": task["cutoff"],
                "cplex_time_s": task["cplex_time"],
                "cplex_status": task["cplex_status"],
                "overtime": 1 if is_overtime else 0,
            }

            diag = result.get("diag", {})
            diag_row = {
                "dataset": dataset, "instance": instance, "seed": seed,
                "best_cost": cost, "opt_cost": opt_cost, "gap_pct": gap,
                "solve_time_s": result.get("solve_time_s", 0),
                "total_swaps": diag.get("total_swaps", 0),
                "total_inferences": diag.get("total_inferences", 0),
                "total_kicks": result.get("kicks", 0),
                "avg_infer_ms": diag.get("avg_infer_ms", 0),
                "swaps_per_second": diag.get("swaps_per_second", 0),
                "nsp_calls": diag.get("nsp_calls", 0),
                "nsp_improvements": diag.get("nsp_improvements", 0),
                "gap_removes_total": diag.get("gap_removes_total", 0),
                "freq_max": diag.get("freq_max", 0),
                "freq_mean": diag.get("freq_mean", 0),
                "cc_conf2_count": diag.get("cc_conf2_count", 0),
                "cc_conf1_count": diag.get("cc_conf1_count", 0),
                "cc_conf0_count": diag.get("cc_conf0_count", 0),
                "longest_stagnation": diag.get("longest_stagnation", 0),
                "improvements_total": diag.get("improvements_total", 0),
                "first_impr_time": diag.get("first_impr_time", -1),
                "last_impr_time": diag.get("last_impr_time", -1),
            }

            with csv_lock:
                w_results.writerow(row)
                w_diag.writerow(diag_row)
                if w_anytime is not None:
                    for t_eff, c in result.get("anytime_trace", []):
                        w_anytime.writerow([dataset, instance, seed,
                                            round(float(t_eff), 4), int(c)])
                completed += 1
                if is_hit:
                    exact_hits += 1
                if is_beat:
                    beats_approx += 1

                if completed % 10 == 0 or completed == total_tasks:
                    f_results.flush()
                    f_diag.flush()
                    if f_anytime is not None:
                        f_anytime.flush()

            elapsed = time.time() - t_start
            rate = completed / max(elapsed, 0.1)
            eta = (total_tasks - completed) / max(rate, 0.001)

            status_tag = "[OPT]" if is_hit else ("[BEAT]" if is_beat else "")
            overtime_tag = ""
            if is_overtime:
                overtime_tag = " *** OVERTIME: feasible solution found after cutoff! ***"
            print(
                f"  [{completed}/{total_tasks}] {dataset}/{instance}_s{seed} "
                f"cost={cost} opt={opt_cost} gap={gap}% "
                f"t={result.get('solve_time_s', 0):.1f}s "
                f"exact_hits={exact_hits} beats={beats_approx} {status_tag}"
                f" | ETA {eta:.0f}s{overtime_tag}",
                flush=True,
            )

    f_results.close()
    f_diag.close()
    if f_anytime is not None:
        f_anytime.close()

    elapsed_total = time.time() - t_start
    print("=" * 70, flush=True)
    print(f"Benchmark complete: {completed} tasks in {elapsed_total:.1f}s "
          f"(exact_hits={exact_hits} beats_approx={beats_approx})", flush=True)
    print(f"  Results: {results_csv}", flush=True)
    print(f"  Diagnostics: {diag_csv}", flush=True)


def main():
    parser = argparse.ArgumentParser(description="M2CDS FAME Benchmark Runner (pure heuristic)")
    parser.add_argument("--problem", choices=["M2CDS"], required=True)
    parser.add_argument("--task_csv", required=True, help="Task CSV from generate_tasks.py")
    parser.add_argument("--data_root", required=True, help="Dataset root directory")
    parser.add_argument("--optima", default=None, help="CPLEX optima CSV/JSON file")
    parser.add_argument("--adaptive", action="store_true",
                        help="Enable adaptive per-instance cutoff based on graph scale "
                             "(V, E, dataset). --cutoff becomes the upper bound.")
    parser.add_argument("--max_batch", type=int, default=48, help="Max parallel threads")
    parser.add_argument("--cutoff", type=float, default=600.0,
                        help="Time cutoff per instance (s). "
                             "With --adaptive, serves as the maximum cutoff.")
    parser.add_argument("--outdir", required=True, help="Output directory for results")
    parser.add_argument("--disable_ale", action="store_true",
                        help="Ablation: No-ALE (both escape levels disabled)")
    parser.add_argument("--disable_nsp", action="store_true",
                        help="Ablation: disable NSP (Solution Pivoting) only")
    parser.add_argument("--disable_car", action="store_true",
                        help="Ablation: disable CAR (Confidence-Adaptive Reconstruct) only")
    parser.add_argument("--disable_stats", action="store_true",
                        help="Ablation: No-Stats (statistics-only control: the elite "
                             "hit frequency h_v is replaced by the neutral constant "
                             "0.5 everywhere FAME consumes it)")
    parser.add_argument("--disable_memory", action="store_true",
                        help="Ablation: No-Memory (elite-memory weight-update skip off)")
    parser.add_argument("--nsp_factor", type=int, default=-1,
                        help="FAME param: NSP trigger max(5000, nsp_factor*n); -1 = engine default (6)")
    parser.add_argument("--nsp_kdiv", type=int, default=-1,
                        help="FAME param: NSP removals max(1, min(|D|/nsp_kdiv, 5)); -1 = engine default (25)")
    parser.add_argument("--car_swap_trigger", type=int, default=-1,
                        help="FAME param: CAR trigger swap_step > car_swap_trigger; -1 = engine default (100)")
    parser.add_argument("--car_eta_base", type=int, default=-1,
                        help="FAME param: CAR removal pct base + (25-base)*n_low/|D|; -1 = engine default (10)")
    parser.add_argument("--elite_skip_threshold", type=float, default=-1.0,
                        help="FAME param: elite-memory skip threshold; -1 = engine default (0.6)")
    parser.add_argument("--w_incl", type=float, default=-1.0,
                        help="Sensitivity coef: NSP keep-score weight of s_incl; <0 = engine default (2.5)")
    parser.add_argument("--w_red", type=float, default=-1.0,
                        help="Sensitivity coef: NSP keep-score weight of s_red; <0 = engine default (1.5)")
    parser.add_argument("--w_hist", type=float, default=-1.0,
                        help="Sensitivity coef: NSP keep-score weight of hist_score; <0 = engine default (0.3)")
    parser.add_argument("--w_repair", type=float, default=-1.0,
                        help="Sensitivity coef: repair warm-start weight of s_incl; <0 = engine default (2.0)")
    parser.add_argument("--w_deg", type=float, default=-1.0,
                        help="Sensitivity coef: repair warm-start weight of score/cost; <0 = engine default (0.3)")
    parser.add_argument("--low_conf", type=float, default=-1.0,
                        help="Sensitivity coef: CAR low-confidence threshold; <0 = engine default (0.3)")
    parser.add_argument("--car_clip", type=float, default=-1.0,
                        help="Sensitivity coef: CAR removal-percent clip bound; <0 = engine default (25)")
    parser.add_argument("--mem_skip_den", type=int, default=-1,
                        help="Sensitivity coef: elite-memory skip denominator (prob (den-1)/den); <2 = engine default (3)")
    parser.add_argument("--big_nodes", type=int, default=2000000,
                        help="Instances with n >= big_nodes are 'huge': they run after "
                             "all normal tasks with at most --big_batch concurrent solves "
                             "(memory guard). Default 2000000.")
    parser.add_argument("--big_batch", type=int, default=12,
                        help="Max concurrent solves for huge instances (default 12).")
    parser.add_argument("--anytime", action="store_true",
                        help="Log per-improvement (effective_time, cost) trace to "
                             "<outdir>/anytime.csv for time-quality curves")
    parser.add_argument("--hard_cutoff", action="store_true",
                        help="Stop each instance exactly at the cutoff. "
                             "If no feasible solution is found by the cutoff, the "
                             "result is recorded as N/A (cost=-1, status=no_feasible).")
    args = parser.parse_args()

    run_benchmark(args)


if __name__ == "__main__":
    main()
