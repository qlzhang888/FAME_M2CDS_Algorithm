#include <iostream>
#include <fstream>
#include<stdio.h>
#include<stdlib.h>
#include<vector>
#include<limits.h>
#include<float.h>
#include <assert.h>
#include<memory.h>
#include<time.h>
#include<unistd.h>
#include<math.h>
#include<set>
#include<algorithm>
#include<utility>
#include <bits/stdc++.h>
#define MAXC 1000000
#define MAXR 500000
using namespace std;
const int maxn=50000;
vector<int>e[maxn];
int dfn[maxn],low[maxn];
int cut[maxn];
int dfs_clock;
typedef struct Vertex_information
{
    int score;
    double score_2fold;
    int time_stamp;
    char is_in_c;
    int cost;
    float cost_2fold;
    int num_in_c;
} Vertex_information;
double parameter_thre;
double parameter_decrese;
Vertex_information cs[MAXC];
int start_time;
double real_time;
clock_t start, finish;
int seed;
int BEST;
double time_limit;
int step;
int total_step;
int best_array[MAXC];
int best_value;
int best_2fold_value;
set<int> tabu_list;
set<int> must_in_C;
set<int> cut_nodes;
int connect_count;
set<int> solution_neibor;
int *confChange;
int vertex_num;
int  **vertex;
int  **vertex_weakly;
int *vertex_neightbourNum;
int *vertex_weakly_neightbourNum;
int *best_sol;
int *best_2fold_sol;
int *vertex_weight;
int *vis;
int *add_vertex_cadidate;
int count_num=0;
int best_count_num=0;
int best_count_2fold_num = 0;
double rate_2fold = 0.80;
void init();
inline int compare(int s1, int c1, int s2, int c2);
void add(int c);
void remove(int c);
int in_tabu(int i);
int find_best_in_c(int allowTabu);
void localsearch(int maxStep);
int cost_C();
void update_best_sol();
void update_best_2fold_sol();
int check();
int check_graph_connect(int v, int mark);
int check_best_solution_connect(int v, int mark);
int check_feasible_best_solution();
int check_current_solution_connect(int v, int mark);
int check_feasible_current_solution();
void init_random();
void grasp(int outter_step,int inner_step);
int check_best_solution_connect_2fold(int v, int mark);
void tarjan(int now,int root,int fa);
void free_all()
{
    free(vertex);
    free(vertex_neightbourNum);
    free(best_sol);
    free(best_2fold_sol);
    free(vertex_weight);
    free(confChange);
}
void build_instance_UDG(char *file)
{
    char line[1024];
    char   tempstr1[10];
    FILE *fp;
    char *tempstr;
    int  temp;
    int  temp1;
    int i,j,h,t;
    int **k;
    int **k2;
    int *k_index;
    int *k2_index;
    int lit;
    int *two_neigh;
    fp = fopen(file, "r");
    if(!fp) { printf("ERROR: cannot open %s\n", file); exit(1); }
    tempstr=fgets(line, 100, fp);
    sscanf(line, "%d",&vertex_num);
    vertex=(int **)malloc(vertex_num*sizeof(int*));
    vertex_weakly=(int **)malloc(vertex_num*sizeof(int*));
    vertex_neightbourNum=(int *)malloc(vertex_num*sizeof(int));
    vertex_weakly_neightbourNum=(int *)malloc(vertex_num*sizeof(int));
    best_sol=(int *)malloc(vertex_num*sizeof(int));
    best_2fold_sol=(int *)malloc(vertex_num*sizeof(int));
    vertex_weight=(int *)malloc(vertex_num*sizeof(int));
    k_index=(int *)malloc(vertex_num*sizeof(int));
    k2_index=(int *)malloc(vertex_num*sizeof(int));
    two_neigh=(int *)malloc(vertex_num*sizeof(int));
    vis = (int *)malloc(vertex_num*sizeof(int));
    add_vertex_cadidate = (int *)malloc(vertex_num*sizeof(int));
    k=(int **)malloc(vertex_num*sizeof(int*));
    k2=(int **)malloc(vertex_num*sizeof(int*));
    confChange = (int *)malloc(vertex_num*sizeof (int));
    for(j=0; j<vertex_num; j++)
    {
        cs[j].time_stamp=1;
        cs[j].is_in_c=0;
        cs[j].num_in_c=0;
        vertex_neightbourNum[j]=0;
        best_sol[j]=0;
        best_2fold_sol[j]=0;
        vertex_weight[j]=0;
        cs[j].cost = 1;
        cs[j].cost_2fold = 1;
        k[j]=(int *)malloc(vertex_num*sizeof(int));
        k2[j]=(int *)malloc(vertex_num*sizeof(int));
    }
    fscanf(fp, "s", tempstr1);
    temp = fscanf(fp, "%d", &i);
    temp1 = fscanf(fp, "%d", &j);
    memset(k_index,0,vertex_num*sizeof(int));
    memset(k2_index,0,vertex_num*sizeof(int));
    memset(confChange,1,vertex_num*sizeof (int));
    while(temp>=0&&temp1>=0)
    {
        for(h=0; h<k_index[i]; h++)
        {
            if(k[i][h]==j)
                break;
        }
        if(h==k_index[i])
        {
            k[i][k_index[i]]=j;
            k_index[i]++;
        }
        for(h=0; h<k_index[j]; h++)
        {
            if(k[j][h]==i)
                break;
        }
        if(h==k_index[j])
        {
            k[j][k_index[j]]=i;
            k_index[j]++;
        }
        fscanf(fp, "s", tempstr1);
        temp = fscanf(fp, "%d", &i);
        temp1 = fscanf(fp, "%d", &j);
    }
    for(i=0; i<vertex_num; i++)
    {
        memset(two_neigh,0,vertex_num*sizeof(int));
        if(k_index[i]==0)
            printf("Neighbour wrong\n");
        for(j = 0; j < k_index[i]; j++)
        {
            int n1 = k[i][j];
            two_neigh[n1] = 1;
            for(h = 0; h < k_index[n1]; h++)
            {
                two_neigh[k[n1][h]] = 1;
            }
        }
        for(j = 0; j < vertex_num; j++)
        {
            if(two_neigh[j])
            {
                k2[i][k2_index[i]]=j;
                k2_index[i]++;
            }
        }
    }
    for(i=0; i<vertex_num; i++)
    {
        vertex_weakly_neightbourNum[i]=k2_index[i];
        vertex_weakly[i]=(int *)malloc( vertex_weakly_neightbourNum[i]*sizeof(int));
        for(j=0; j< vertex_weakly_neightbourNum[i]; j++)
            vertex_weakly[i][j]=k2[i][j];
    }
    for(i=0; i<vertex_num; i++)
    {
        if(k_index[i]==0)
            printf("Neighbour wrong\n");
        vertex_neightbourNum[i]=k_index[i];
        vertex[i]=(int *)malloc( vertex_neightbourNum[i]*sizeof(int));
        for(j=0; j< vertex_neightbourNum[i]; j++)
            vertex[i][j]=k[i][j];
        vertex_weight[i]=1;
        cs[i].score=vertex_neightbourNum[i]+1;
        cs[i].score_2fold = (vertex_neightbourNum[i]) * (1 - rate_2fold);
    }
    free(k);
    fclose(fp);
    int min_cover=INT_MAX, max_cover=0;
    int avg_cover, sum=0;
    for(i=0; i<vertex_num; i++)
    {
        if(min_cover>vertex_neightbourNum[i])
            min_cover=vertex_neightbourNum[i];
        if(max_cover<vertex_neightbourNum[i])
            max_cover=vertex_neightbourNum[i];
        sum+=vertex_neightbourNum[i];
    }
    avg_cover=sum/(2*vertex_num);
}
int check_graph_connect(int v, int mark)
{
    vis[v]=mark;
    connect_count++;
    if(connect_count==vertex_num)
        return 0;
    for(int i=0; i<vertex_neightbourNum[v]; i++)
    {
        if(vis[vertex[v][i]]!=mark)
            check_graph_connect(vertex[v][i], mark);
    }
    return 0;
}
int check_feasible_best_solution()
{
    connect_count=0;
    int j;
    for(j=0; j<vertex_num; j++)
    {
        if(best_sol[j]==1)
        {
            memset(vis,0,vertex_num*sizeof(int));
            check_best_solution_connect(j,1);
            break;
        }
    }
    if(connect_count!=best_count_num)
        return 0;
    return 1;
}
int check_feasible_best_solution_2fold()
{
    connect_count=0;
    int j;
    for(j = 0; j < vertex_num; j++)
    {
        if(best_2fold_sol[j] == 1)
        {
            memset(vis,0,vertex_num*sizeof(int));
            check_best_solution_connect_2fold(j,1);
            break;
        }
    }
    if(connect_count!=best_count_2fold_num)
        return 0;
    return 1;
}
int check_best_solution_connect(int v, int mark)
{
    vis[v]=mark;
    connect_count++;
    for(int i=0; i<vertex_neightbourNum[v]; i++)
    {
        if(vis[vertex[v][i]]!=mark && best_sol[vertex[v][i]]==1)
            check_best_solution_connect(vertex[v][i], mark);
    }
    return 0;
}
int check_best_solution_connect_2fold(int v, int mark)
{
    vis[v]=mark;
    connect_count++;
    for(int i=0; i<vertex_neightbourNum[v]; i++)
    {
        if(vis[vertex[v][i]]!=mark && best_2fold_sol[vertex[v][i]]==1)
            check_best_solution_connect_2fold(vertex[v][i], mark);
    }
    return 0;
}
int check_feasible_current_solution()
{
    connect_count=0;
    int j;
    for(j=0; j<vertex_num; j++)
    {
        if(cs[j].is_in_c==1)
        {
            memset(vis,0,vertex_num*sizeof(int));
            check_current_solution_connect(j,1);
            break;
        }
    }
    cost_C();
    if(connect_count==count_num)
        return 1;
    else
        return 0;
}
int check_current_solution_connect(int v, int mark)
{
    vis[v]=mark;
    connect_count++;
    for(int i=0; i<vertex_neightbourNum[v]; i++)
    {
        if(vis[vertex[v][i]]!=mark && cs[vertex[v][i]].is_in_c==1)
            check_current_solution_connect(vertex[v][i], mark);
    }
    return 0;
}
int check_current_solution_2fold(){
    set<int>::reverse_iterator it;
    for(it = solution_neibor.rbegin(); it!=solution_neibor.rend(); it++){
        if(cs[*it].num_in_c<2)
            return 0;
    }
    return 1;
}
