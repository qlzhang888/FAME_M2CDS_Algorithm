#include "greedy_2fold.hpp"
int check()
{
    int i,j,k;
    int t[MAXR];
    memset(t,0,MAXR*sizeof(int));
    for(j=0; j<vertex_num; j++)
    {
        if(best_sol[j]==0)
            continue;
        t[j]=1;
        for(k=0; k<vertex_neightbourNum[j]; k++)
        {
            t[vertex[j][k]]=1;
        }
    }
    for(i=0; i<vertex_num; i++)
    {
        if(vertex_neightbourNum[i]&&!t[i])
            return 0;
    }
    if(check_feasible_best_solution()==0)
        return 0;
    return 1;
}
int check_2fold_connect()
{
    int i,j,k;
    int t[MAXR];
    int count_2fold=0;
    memset(t,0,MAXR*sizeof(int));
    for(j=0; j<vertex_num; j++)
    {
        if(best_2fold_sol[j] == 0){
            for(k=0;k<vertex_neightbourNum[j];k++){
                if(best_2fold_sol[vertex[j][k]] == 1){
                    count_2fold++;
                }
            }
            if(count_2fold<2){
                return 0;
            }
            count_2fold = 0;
        }
    }
    if(check_feasible_best_solution_2fold()==0)
        return 0;
    return 1;
}
int cost_C()
{
    int s=0,j;
    count_num=0;
    for(j=0; j<vertex_num; j++)
    {
        if(cs[j].is_in_c)
        {
            s+=1;
            count_num++;
        }
    }
    return s;
}
void update_best_2fold_sol()
{
    int i,j;
    int k = cost_C();
    if(k < best_2fold_value)
    {
        best_count_2fold_num = count_num;
        best_2fold_value = k;
        for(j=0; j<vertex_num; j++)
        {
            best_2fold_sol[j]=0;
            if(cs[j].is_in_c)
            {
                best_2fold_sol[j]=1;
            }
        }
        if(check_2fold_connect()==0)
        {
            printf("wrong: not 2-fold CDS. ***this information is from update_best_2fold_sol()***\n");
            exit(0);
        }
        printf("The best 2-fold solution has been updated, @@@@@@ best_count_2fold_num: %d best_2fold_value: %d\n",best_count_2fold_num,best_2fold_value);
    }
}
void spanning_Subgraph(){
    int i = 0, j = 0;
    int flag = 1;
    for(i = 0; i < vertex_num; i++){
        if(C[i] == 1){
            for(int k = 0; k < vertex_neightbourNum[i]; k++){
                spanning_subgraph[i][k] = vertex[i][k];
            }
            spanning_subgraph_vertex_neiNum[i] = vertex_neightbourNum[i];
            continue;
        }
        flag = 1;
        for(j = 0; j < vertex_neightbourNum[i]; j++){
            if(C[vertex[i][j]] == 1 && flag == 1){
                spanning_subgraph_vertex_neiNum[i] = 0;
                flag = 0;
            }
            if(C[vertex[i][j]] == 1){
                spanning_subgraph[i][spanning_subgraph_vertex_neiNum[i]] = vertex[i][j];
                spanning_subgraph_vertex_neiNum[i]++;
            }
        }
    }
}
void check_current_solution_connect_p_C(int v, int mark){
    vis[v] = mark;
    connect_count++;
    for(int i = 0; i < vertex_neightbourNum[v]; i++){
        if(C[vertex[v][i]] == 1){
            if(vis[vertex[v][i]] != mark){
                check_current_solution_connect_p_C(vertex[v][i], mark);
            }
        }
    }
}
int find_num_of_components_p_C(){
    int cnt = 0;
    int sum_connect_count = 0;
    int count_C = 0;
    int i;
    connect_count = 0;
    sum_connect_count = 0;
    memset(vis,0,vertex_num*sizeof(int));
    count_C = 0;
    for(i = 0; i < vertex_num; i++){
        if(C[i] == 1){
            count_C++;
        }
    }
    while(sum_connect_count != count_C){
        cnt++;
        for(i = 0; i < vertex_num; i++){
            if(C[i] == 1){
                if(vis[i] == 0){
                    connect_count = 0;
                    check_current_solution_connect_p_C(i, cnt);
                    break;
                }
            }
        }
        sum_connect_count += connect_count;
    }
    return cnt;
}
void check_current_solution_connect_q_C(int v, int mark){
    vis[v] = mark;
    connect_count++;
    for(int i = 0; i < spanning_subgraph_vertex_neiNum[v]; i++){
        if(spanning_subgraph_vertex_neiNum[spanning_subgraph[v][i]] > 0){
            if(vis[spanning_subgraph[v][i]] != mark){
                check_current_solution_connect_q_C(spanning_subgraph[v][i], mark);
            }
        }
    }
}
int find_num_of_components_q_C(){
    int cnt = 0;
    int sum_connect_count = 0;
    int count_spanning_subgraph = 0;
    int i;
    connect_count = 0;
    sum_connect_count = 0;
    memset(vis,0,vertex_num*sizeof(int));
    count_spanning_subgraph = 0;
    for(i = 0; i < vertex_num; i++){
        if(spanning_subgraph_vertex_neiNum[i] > 0){
            count_spanning_subgraph++;
        }
    }
    while(sum_connect_count != count_spanning_subgraph){
        cnt++;
        for(i = 0; i < vertex_num; i++){
            if(spanning_subgraph_vertex_neiNum[i] > 0){
                if(vis[i] == 0){
                    connect_count = 0;
                    check_current_solution_connect_q_C(i, cnt);
                    break;
                }
            }
        }
        sum_connect_count += connect_count;
    }
    return vertex_num - count_spanning_subgraph + cnt;
}
int sum_m_C(){
    int i = 0, j = 0, k = 0;
    int neighbor_in_C_count = 0;
    int sum = 0;
    memset(N_c,0,vertex_num*sizeof(int));
    for(i = 0; i < vertex_num; i++){
        neighbor_in_C_count = 0;
        for(j = 0; j < vertex_neightbourNum[i]; j++) {
            if (C[vertex[i][j]] == 1) {
                neighbor_in_C_count++;
            }
        }
        N_c[i] = neighbor_in_C_count;
    }
    sum = 0;
    for(i = 0; i < vertex_num; i++){
        if(N_c[i] < 2 && C[i] == 0){
            sum++;
        }
    }
    return sum;
}
int f_C(){
    int p_C = 0;
    int q_C = 0;
    int m_C = 0;
    p_C = find_num_of_components_p_C();
    memset(spanning_subgraph_vertex_neiNum,0,vertex_num*sizeof(int));
    spanning_Subgraph();
    q_C = find_num_of_components_q_C();
    m_C = sum_m_C();
    return p_C + q_C + m_C;
}
int delta_x_f_C(int x){
    int delta = 0;
    int f_C_plus_x = 0;
    int f_C_original = 0;
    C[x] = 1;
    f_C_plus_x = f_C();
    C[x] = 0;
    f_C_original = f_C();
    delta = f_C_plus_x - f_C_original;
    return delta;
}
static std::chrono::steady_clock::time_point wd_t0;
double best_time_wall = -1.0;
static void wd_tick(std::string fname, int sd, double limit) {
    int last_best = INT_MAX;
    for (;;) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        double el = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - wd_t0).count();
        int b = best_2fold_value;
        if (b > 0 && b < last_best) { last_best = b; best_time_wall = el; }
        if (el >= limit) {
            printf("RESULT %s %d %d %.2f\n", fname.c_str(), sd, last_best,
                   best_time_wall >= 0.0 ? best_time_wall : el);
            fflush(NULL);
            _exit(0);
        }
    }
}
int main(int argc, char *argv[])
{
    char filename[200];
    int seed_val = 1;
    double tl = 600.0;
    if (argc >= 4) {
        strcpy(filename, argv[1]);
        seed_val = atoi(argv[2]);
        tl = atof(argv[3]);
    } else if (argc == 1) {
        strcpy(filename, "400_60_80.mtx");
        seed_val = 1;
        tl = 600.0;
    } else {
        printf("Usage: %s <filename> <seed> <time_limit>\n", argv[0]);
        return 1;
    }
    srand(seed_val);
    build_instance_UDG(filename);
    clock_t t_start = clock();
    wd_t0 = std::chrono::steady_clock::now();
    std::thread(wd_tick, std::string(filename), seed_val, tl).detach();
    int i, j, k;
    int max_delta = 0;
    int delta_temp = 0;
    int max_delta_vertex = 0;
    m = 2;
    memset(C,0,vertex_num*sizeof(int));
    i=0;
    while (1) {
        max_delta = 0;
        max_delta_vertex = 0;
        for (j = 0; j < vertex_num; j++) {
            if (C[j] == 0) {
                delta_temp = -delta_x_f_C(j);
                if (delta_temp > max_delta) {
                    max_delta = delta_temp;
                    max_delta_vertex = j;
                }
            }
        }
        if(max_delta <= 0){
            break;
        }
        C[max_delta_vertex] = 1;
        i++;
    }
    for(k = 0; k < vertex_num; k++){
        if(C[k] == 1){
            cs[k].is_in_c = 1;
        }
    }
    best_2fold_value = INT_MAX;
    update_best_2fold_sol();
    clock_t t_end = clock();
    double elapsed = double(t_end - t_start)/(double)CLOCKS_PER_SEC;
    printf("RESULT %s %d %d %.2f\n", filename, seed_val, best_2fold_value, best_time_wall >= 0.0 ? best_time_wall : elapsed);
    return 0;
}
