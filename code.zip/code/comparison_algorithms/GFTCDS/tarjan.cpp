#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=20000+10;
int n,m;
vector<int>e[maxn];
int dfn[maxn],low[maxn];
int cut[maxn];
int dfs_clock;
void tarjan(int now,int root,int fa)
{
    dfn[now]=low[now]=++dfs_clock;
    int child=0;
    for(int i=0;i<e[now].size();i++)
    {
        int to=e[now][i];
        if(!dfn[to])
        {
            child++;
            tarjan(to,root,now);
            low[now]=min(low[now],low[to]);
            if(low[to]>=dfn[now]&&now!=root) cut[now]=1;
        }
        else if(to!=fa) low[now]=min(low[now],dfn[to]);
    }
    if(child>=2&&now==root) cut[now]=1;
}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        int u,v;
        scanf("%d%d",&u,&v);
        e[u].push_back(v);
        e[v].push_back(u);
    }
    dfs_clock=0;
    for(int i=1;i<=n;i++)
        if(!dfn[i]) tarjan(i,i,-1);
    int cnt=0;
    for(int i=1;i<=n;i++) if(cut[i]) cnt++;
    printf("%d\n",cnt);
    for(int i=1;i<=n;i++) if(cut[i]) printf("%d ",i);
    printf("\n");
    return 0;
}
