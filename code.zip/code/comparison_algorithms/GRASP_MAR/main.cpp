#include "grasp_cds.hpp"
int uncover_num;
int only_1fold_num = 0;
int only_2fold_num = 0;
double finish_time;
int sum_weight=INT_MAX;
void init()
{
    int i;
    uncover_num=vertex_num;
    only_1fold_num = 0;
    only_2fold_num = 0;
    memset(confChange,1,vertex_num*sizeof (int));
    int j;
    for(j=0; j<vertex_num; j++)
    {
        cs[j].time_stamp=1;
        cs[j].is_in_c=0;
        cs[j].num_in_c=0;
        cs[j].score_2fold = (vertex_neightbourNum[j]) * (1.0 - rate_2fold);
    }
    int k;
    for(i=0; i<vertex_num; i++)
    {
        cs[i].score=vertex_weight[i];
        for(j=0; j<vertex_neightbourNum[i]; j++)
        {
            k=vertex[i][j];
            cs[i].score+=vertex_weight[k];
        }
    }
    tabu_list.clear();
    must_in_C.clear();
    cut_nodes.clear();
    e->clear();
}
inline int compare(int s1, int c1, int s2, int c2)
{
    if(c1==c2)
    {
        if(s1>s2)
            return 1;
        else if(s1==s2)
            return 0;
        else
            return -1;
    }
    return 0;
}
inline int compare_double(double s1, int c1, double s2, int c2)
{
    if(c1==c2)
    {
        if(s1>s2)
            return 1;
        else if(s1==s2)
            return 0;
        else
            return -1;
    }
    return 0;
}
inline int rm_compare(int s1, int c1, int s2, int c2)
{
    if(c1==c2)
    {
        if(s1>s2)
            return 1;
        else if(s1==s2)
            return 0;
        else
            return -1;
    }
    return 0;
}
inline int rm_compare_double(double s1, int c1, double s2, int c2)
{
    if(c1==c2)
    {
        if(s1>s2)
            return 1;
        else if(s1==s2)
            return 0;
        else
            return -1;
    }
    return 0;
}
int check()
{
    int i,j,k;
    int t[MAXR];
    memset(t,0,MAXR*sizeof(int));
    for(j=0; j<vertex_num; j++)
    {
        if(best_sol[j]==0)
            continue;
        t[j]=1;
        for(k=0; k<vertex_neightbourNum[j]; k++)
        {
            t[vertex[j][k]]=1;
        }
    }
    for(i=0; i<vertex_num; i++)
    {
        if(vertex_neightbourNum[i]&&!t[i])
            return 0;
    }
    if(check_feasible_best_solution()==0)
        return 0;
    return 1;
}
int check_2fold_connect()
{
    int i,j,k;
    int t[MAXR];
    int count_2fold=0;
    memset(t,0,MAXR*sizeof(int));
    for(j=0; j<vertex_num; j++)
    {
        if(best_2fold_sol[j] == 0){
            for(k=0;k<vertex_neightbourNum[j];k++){
                if(best_2fold_sol[vertex[j][k]] == 1){
                    count_2fold++;
                }
            }
            if(count_2fold<2){
                return 0;
            }
            count_2fold = 0;
        }
    }
    if(check_feasible_best_solution_2fold()==0)
        return 0;
    return 1;
}
void init_random()
{
    int i,j,k,l;
    int index_rand;
    double min=INT_MAX;
    double max=INT_MIN;
    int solution_neibor_temp[vertex_num];
    min=INT_MAX;
    max=INT_MIN;
    for(j=0; j<vertex_num; j++)
    {
        if(cs[j].score>max)
            max=cs[j].score;
        if(cs[j].score<min)
            min=cs[j].score;
    }
    int RCL=(min+(max-min)*0.99)+0.5;
    index_rand=rand()%vertex_num;
    while(1)
    {
        if(cs[index_rand].score>=RCL)
            break;
        index_rand=(index_rand+1)%vertex_num;
    }
    if(cs[index_rand].is_in_c == 0)
        add(index_rand);
    for(i=0; i<vertex_neightbourNum[index_rand]; i++)
    {
        if(cs[vertex[index_rand][i]].is_in_c == 0)
            solution_neibor.insert(vertex[index_rand][i]);
    }
    set<int>::reverse_iterator it;
    while(uncover_num>0)
    {
        min=INT_MAX;
        max=INT_MIN;
        int solution_neibor_temp_number=0;
        for(it = solution_neibor.rbegin(); it!=solution_neibor.rend(); it++)
        {
            if(cs[*it].score>max)
                max=cs[*it].score;
            if(cs[*it].score<min)
                min=cs[*it].score;
            solution_neibor_temp[solution_neibor_temp_number]=*it;
            solution_neibor_temp_number++;
        }
        RCL=(min+(max-min)*0.99)+0.5;
        index_rand=rand()%solution_neibor_temp_number;
        while(1)
        {
            if(cs[solution_neibor_temp[index_rand]].score>=RCL)
                break;
            index_rand=(index_rand+1)%solution_neibor_temp_number;
        }
        if(cs[solution_neibor_temp[index_rand]].is_in_c == 0)
            add(solution_neibor_temp[index_rand]);
        solution_neibor.erase(solution_neibor_temp[index_rand]);
        for(i=0; i<vertex_neightbourNum[solution_neibor_temp[index_rand]]; i++)
        {
            if(cs[vertex[solution_neibor_temp[index_rand]][i]].is_in_c==0)
                solution_neibor.insert(vertex[solution_neibor_temp[index_rand]][i]);
        }
    }
    update_best_sol();
    for(auto it2 = solution_neibor.begin(); it2 != solution_neibor.end(); ){
        int lonely_node = *it2;
        if(vertex_neightbourNum[lonely_node] == 1){
            if(cs[lonely_node].is_in_c == 0)
                add(lonely_node);
            must_in_C.insert(lonely_node);
            it2 = solution_neibor.erase(it2);
        } else {
            ++it2;
        }
    }
    int max_neighbor_num_temp = 0;
    int max_neighbor_num = INT_MIN;
    int not2fold_with_max_neighbor_vertex;
    while((uncover_num + only_1fold_num)!=0){
        for(int not2fold_vertex_temp : solution_neibor){
            if(cs[not2fold_vertex_temp].num_in_c < 2){
                max_neighbor_num_temp = vertex_neightbourNum[not2fold_vertex_temp];
                if(max_neighbor_num_temp >= max_neighbor_num){
                    max_neighbor_num = max_neighbor_num_temp;
                    not2fold_with_max_neighbor_vertex = not2fold_vertex_temp;
                }
            }
        }
        if(cs[not2fold_with_max_neighbor_vertex].is_in_c == 0)
            add(not2fold_with_max_neighbor_vertex);
        max_neighbor_num = INT_MIN;
        solution_neibor.erase(not2fold_with_max_neighbor_vertex);
    }
    update_best_2fold_sol();
    solution_neibor.clear();
    if(check_2fold_connect()==0){
        printf("initial wrong: not a 2-fold CDS.\n");
        exit(0);
    }
}
void add(int c)
{
    int i,j,k,t,cnt,s, ii, jj, ix,h, l;
    int ran_temp = rand()%(vertex_neightbourNum[c]+1);
    int adp_temp = 0;
    for(i = 0; i < vertex_neightbourNum[c]; i++){
        int v = vertex[c][i];
        if(ran_temp!=0){
            confChange[v] = 1;
            ran_temp--;
        }
        if(cs[v].is_in_c == 1){
            adp_temp++;
            continue;
        }
        if(cs[v].num_in_c == 0){
            only_1fold_num++;
        }else if(cs[v].num_in_c == 1){
            only_1fold_num--;
            only_2fold_num++;
        }else{
            continue;
        }
    }
    if(adp_temp == 1){
        only_1fold_num--;
    }else if(adp_temp >= 2){
        only_2fold_num--;
    }
    cs[c].is_in_c=1;
    cs[c].score = -cs[c].score;
    if( cs[c].num_in_c==0)
        uncover_num--;
    for(h=0; h<vertex_neightbourNum[c]; h++)
    {
        i=vertex[c][h];
        if(cs[i].num_in_c==0)
            uncover_num--;
        cs[i].num_in_c++;
        cnt=0;
        if( cs[c].num_in_c==0)
        {
            cs[i].score-=vertex_weight[c];
        }
        else if( cs[c].num_in_c==1&& cs[i].is_in_c==1)
        {
            cs[i].score+=vertex_weight[c];
        }
        for(l=0; l<vertex_neightbourNum[i]; l++)
        {
            j=vertex[i][l];
            if(j==c)
                continue;
            if(cs[j].is_in_c)
            {
                s=j;
                cnt++;
            }
        }
        if(cs[i].is_in_c)
        {
            s=i;
            cnt++;
        }
        if(cnt==0)
        {
            cs[i].score-=vertex_weight[i];
            for(l=0; l<vertex_neightbourNum[i]; l++)
            {
                j=vertex[i][l];
                if(j==c)
                    continue;
                cs[j].score-=vertex_weight[i];
            }
        }
        else if(cnt==1)
        {
            cs[s].score+=vertex_weight[i];
        }
    }
    cs[c].num_in_c++;
    int count_2fold_temp=0, count_1fold_temp=0;
    for(h = 0; h < vertex_neightbourNum[c]; h++){
        int v = vertex[c][h];
        if(cs[v].is_in_c == 1)
            continue;
        if(cs[v].num_in_c == 1){
            count_1fold_temp++;
        }else if(cs[v].num_in_c == 2){
            count_2fold_temp++;
            count_1fold_temp--;
        }else{
            continue;
        }
    }
    cs[c].score_2fold = -((count_1fold_temp * (1.0 - rate_2fold)) + (count_2fold_temp * rate_2fold));
    count_1fold_temp = 0; count_2fold_temp = 0;
    for(h = 0; h < vertex_neightbourNum[c]; h++){
        int v = vertex[c][h];
        if(cs[v].is_in_c == 0) {
           for(i = 0; i < vertex_neightbourNum[v]; i++){
               int u = vertex[v][i];
               if(cs[u].is_in_c == 1)
                   continue;
               if(cs[u].num_in_c == 1){
                   count_2fold_temp++;
               }
               else if(cs[u].num_in_c == 0)
                   count_1fold_temp++;
               else
                   continue;
           }
           cs[v].score_2fold = ((1.0-rate_2fold) * count_1fold_temp) + (rate_2fold * count_2fold_temp);
           count_1fold_temp = 0;
           count_2fold_temp = 0;
        }else{
            for(i = 0; i < vertex_neightbourNum[v]; i++){
                int u = vertex[v][i];
                if(cs[u].is_in_c == 1)
                    continue;
                if(cs[u].num_in_c == 1)
                    count_1fold_temp++;
                else if(cs[u].num_in_c == 2) {
                    count_2fold_temp++;
                    count_1fold_temp--;
                }
                else
                    continue;
            }
            cs[v].score_2fold = -(((1.0 - rate_2fold) * count_1fold_temp) + (rate_2fold * count_2fold_temp));
            count_1fold_temp = 0;
            count_2fold_temp = 0;
        }
    }
}
void remove(int c)
{
    confChange[c] = 0;
    int i,j,k,t,cnt,s,h,l;
    int ran_temp = rand()%(vertex_neightbourNum[c]+1);
    int adp_temp = 0;
    for(i = 0; i < vertex_neightbourNum[c]; i++){
        int v = vertex[c][i];
        if(ran_temp!=0){
            confChange[v] = 1;
            ran_temp--;
        }
        if(cs[v].is_in_c == 1){
            adp_temp++;
            continue;
        }
        if(cs[v].num_in_c == 1){
            only_1fold_num--;
        }else if(cs[v].num_in_c == 2){
            only_1fold_num++;
            only_2fold_num--;
        }else{
            continue;
        }
    }
    if(adp_temp == 1){
        only_1fold_num++;
    }else if(adp_temp >= 2){
        only_2fold_num++;
    }
    cs[c].is_in_c=0;
    cs[c].score=-cs[c].score;
    if( cs[c].num_in_c==1)
        uncover_num++;
    for(h=0; h<vertex_neightbourNum[c]; h++)
    {
        i=vertex[c][h];
        if(cs[i].num_in_c==1)
            uncover_num++;
        cs[i].num_in_c--;
        cnt=0;
        if( cs[c].num_in_c==2&& cs[i].is_in_c==1)
        {
            cs[i].score-=vertex_weight[c];
        }
        else if( cs[c].num_in_c==1)
        {
            cs[i].score+=vertex_weight[c];
        }
        for(l=0; l<vertex_neightbourNum[i]; l++)
        {
            j=vertex[i][l];
            if(j==c)
                continue;
            if(cs[j].is_in_c)
            {
                cnt++;
                s=j;
            }
        }
        if(cs[i].is_in_c)
        {
            s=i;
            cnt++;
        }
        if(cnt==0)
        {
            cs[i].score+=vertex_weight[i];
            for(l=0; l<vertex_neightbourNum[i]; l++)
            {
                j=vertex[i][l];
                if(j==c)
                    continue;
                cs[j].score+=vertex_weight[i];
            }
        }
        else if(cnt==1)
        {
            cs[s].score-=vertex_weight[i];
        }
    }
    cs[c].num_in_c--;
    int count_2fold_temp=0, count_1fold_temp=0;
    for(h = 0; h < vertex_neightbourNum[c]; h++) {
        int v = vertex[c][h];
        if(cs[v].is_in_c == 1)
            continue;
        if(cs[v].num_in_c == 1){
            count_2fold_temp++;
        }
        else if(cs[v].num_in_c == 0)
            count_1fold_temp++;
        else
            continue;
    }
    cs[c].score_2fold = ((1.0 - rate_2fold) * count_1fold_temp) + (rate_2fold * count_2fold_temp);
    count_1fold_temp = 0;
    count_2fold_temp = 0;
    for(h = 0; h < vertex_neightbourNum[c]; h++){
        int v = vertex[c][h];
        if(cs[v].is_in_c == 0) {
            for(i = 0; i < vertex_neightbourNum[v]; i++){
                int u = vertex[v][i];
                if(cs[u].is_in_c == 1)
                    continue;
                if(cs[u].num_in_c == 1){
                    count_2fold_temp++;
                }
                else if(cs[u].num_in_c == 0)
                    count_1fold_temp++;
                else
                    continue;
            }
            cs[v].score_2fold = ((1.0 - rate_2fold) * count_1fold_temp) + (rate_2fold * count_2fold_temp);
            count_1fold_temp = 0;
            count_2fold_temp = 0;
        }else{
            for(i = 0; i < vertex_neightbourNum[v]; i++){
                int u = vertex[v][i];
                if(cs[u].is_in_c == 1)
                    continue;
                if(cs[u].num_in_c == 1)
                    count_1fold_temp++;
                else if(cs[u].num_in_c == 2) {
                    count_2fold_temp++;
                    count_1fold_temp--;
                }
                else
                    continue;
            }
            cs[v].score_2fold = -(((1.0 - rate_2fold) * count_1fold_temp) + (rate_2fold * count_2fold_temp));
            count_1fold_temp = 0;
            count_2fold_temp = 0;
        }
    }
}
int in_tabu(int i)
{
    return tabu_list.find(i)!=tabu_list.end();
}
int in_must_in_C(int i)
{
    return must_in_C.find(i)!=must_in_C.end();
}
int in_cut_nodes(int i){
    return cut_nodes.find(i)!=cut_nodes.end();
}
int state=0;
int find_best_in_c(int allowTabu)
{
    int i, maxc,j,k;
    double sr=DBL_MIN;
    int ct=1;
    state=0;
    for(i=0; i<vertex_num; i++)
    {
        if(cs[i].is_in_c == 0)
            continue;
        if(in_must_in_C(i))
            continue;
        if(allowTabu&&(confChange[i]==0)){
            continue;
        }
        state=1;
        k=rm_compare_double(sr,ct, cs[i].score_2fold, cs[i].cost);
        if(sr==DBL_MIN||k<0)
        {
            sr=cs[i].score_2fold;
            ct=cs[i].cost;
            maxc=i;
        }
        else if(k==0)
        {
            if(cs[maxc].time_stamp>cs[i].time_stamp)
            {
                maxc=i;
            }
        }
    }
    return maxc;
}
void localsearch(int maxStep)
{
    step=1;
    int i,j,k,h,l;
    int best_in_c;
    int maxc;
    int flag[vertex_num];
    int noImpro_step=0,remove_rand_vertex;
    while(step<=maxStep)
    {
        if(step % 10000 == 0) {
            finish = clock();
            real_time = double(finish - start)/(double)CLOCKS_PER_SEC;
            if(real_time > time_limit) return;
        }
        if((uncover_num + only_1fold_num)==0)
        {
            if(check_feasible_current_solution()==1)
            {
                int best2fold_beforeUpdate = cost_C();
                update_best_sol();
                update_best_2fold_sol();
                if(best_2fold_value < best2fold_beforeUpdate){
                    noImpro_step = 0;
                }else{
                    noImpro_step++;
                }
                if(noImpro_step%100==0){
                    remove_rand_vertex = rand()%vertex_num;
                    while (1){
                        if(cs[remove_rand_vertex].is_in_c==1)
                            break;
                        remove_rand_vertex = (rand()+1)%vertex_num;
                    }
                    maxc=remove_rand_vertex;
                }else{
                    maxc=find_best_in_c(0);
                }
                remove(maxc);
                continue;
            }
        }
        best_in_c=find_best_in_c(1);
        if(state==0){
            best_in_c=find_best_in_c(0);
        }
        remove(best_in_c);
        tabu_list.clear();
        connect_count=0;
        for(j=0; j<vertex_num; j++)
        {
            if(cs[j].is_in_c==1)
            {
                memset(vis,0,vertex_num*sizeof(int));
                check_current_solution_connect(j,2);
                break;
            }
        }
        cost_C();
        int cost=count_num;
        while((uncover_num + only_1fold_num)>0 || connect_count!=cost)
        {
            double sr=DBL_MIN;
            int ct;
            maxc=0;
            int cnt=0;
            connect_count=0;
            int sum_connect_num=0;
            memset(vis,0,vertex_num*sizeof(int));
            memset(add_vertex_cadidate,0,vertex_num*sizeof(int));
            while(cost!=sum_connect_num)
            {
                cnt++;
                for(i=0; i<vertex_num; i++)
                {
                    if(vis[i]==0 && cs[i].is_in_c==1)
                    {
                        connect_count=0;
                        check_current_solution_connect(i,cnt);
                        break;
                    }
                }
                sum_connect_num += connect_count;
            }
            for(i=1; i<=cnt; i++)
            {
                memset(flag,0,vertex_num*sizeof(int));
                for(j=0; j<vertex_num; j++)
                {
                    if(vis[j]==i)
                    {
                        for(k=0; k<vertex_neightbourNum[j]; k++)
                        {
                            if(cs[vertex[j][k]].is_in_c==0 && flag[vertex[j][k]]==0)
                            {
                                add_vertex_cadidate[vertex[j][k]]++;
                                flag[vertex[j][k]]=1;
                            }
                        }
                    }
                }
            }
            bool greedyChangeFlag = false;
            if(cnt>1 && only_1fold_num!=0){
                double random05 = rand()%(101)/double (100);
                if(random05>0.50){
                    greedyChangeFlag = true;
                }
            }
            if(greedyChangeFlag){
                while(cnt-1)
                {
                    int temp=0;
                    for(j=0; j<vertex_num; j++)
                    {
                        if(add_vertex_cadidate[j]!=cnt)
                            continue;
                        temp++;
                        k=compare_double(sr,ct, cs[j].score_2fold, cs[j].cost);
                        if(sr==DBL_MIN||k<0)
                        {
                            sr=cs[j].score_2fold;
                            ct=cs[j].cost;
                            maxc=j;
                        }
                        else if(k==0&&cs[maxc].time_stamp>=cs[j].time_stamp)
                        {
                            maxc=j;
                        }
                    }
                    if(temp!=0)
                        break;
                    else
                        cnt--;
                }
            } else {
                while(cnt)
                {
                    int temp=0;
                    for(j=0; j<vertex_num; j++)
                    {
                        if(add_vertex_cadidate[j]!=cnt)
                            continue;
                        temp++;
                        k=compare_double(sr,ct, cs[j].score_2fold, cs[j].cost);
                        if(sr==DBL_MIN||k<0)
                        {
                            sr=cs[j].score_2fold;
                            ct=cs[j].cost;
                            maxc=j;
                        }
                        else if(k==0&&cs[maxc].time_stamp>=cs[j].time_stamp)
                        {
                            maxc=j;
                        }
                    }
                    if(temp!=0)
                        break;
                    else
                        cnt--;
                }
            }
            if(cs[maxc].is_in_c == 0)
                add(maxc);
            tabu_list.insert(maxc);
            connect_count=0;
            for(j=0; j<vertex_num; j++)
            {
                if(cs[j].is_in_c==1)
                {
                    memset(vis,0,vertex_num*sizeof(int));
                    check_current_solution_connect(j,1);
                    break;
                }
            }
            cost_C();
            cost=count_num;
        }
        step++;
    }
}
int cost_C()
{
    int s=0,j;
    count_num=0;
    for(j=0; j<vertex_num; j++)
    {
        if(cs[j].is_in_c)
        {
            s+=1;
            count_num++;
        }
    }
    return s;
}
void tarjan(int now,int root,int fa)
{
    dfn[now]=low[now]=++dfs_clock;
    int child=0;
    for(int i=0;i<e[now].size();i++)
    {
        int to=e[now][i];
        if(!dfn[to])
        {
            child++;
            tarjan(to,root,now);
            low[now]=min(low[now],low[to]);
            if(low[to]>=dfn[now]&&now!=root) cut[now]=1;
        }
        else if(to!=fa) low[now]=min(low[now],dfn[to]);
    }
    if(child>=2&&now==root) cut[now]=1;
}
void update_best_sol()
{
    int i,j;
    int k=cost_C();
    if(k<best_value)
    {
        best_count_num=count_num;
        best_value=k;
        for(j=0; j<vertex_num; j++)
        {
            best_sol[j]=0;
            if(cs[j].is_in_c)
            {
                best_sol[j]=1;
            }
        }
        if(check()==0)
        {
            printf("wrong\n");
            exit(0);
        }
        finish = clock();
        real_time = double(finish - start)/(double)CLOCKS_PER_SEC;
        printf("The best solution has been updated, @@@@@@ best_count_num: %d best_value: %d\n",best_count_num,best_value);
    }
}
void update_best_2fold_sol()
{
    int i,j;
    int k = cost_C();
    if(k < best_2fold_value)
    {
        best_count_2fold_num = count_num;
        best_2fold_value = k;
        for(j=0; j<vertex_num; j++)
        {
            best_2fold_sol[j]=0;
            if(cs[j].is_in_c)
            {
                best_2fold_sol[j]=1;
            }
        }
        if(check_2fold_connect()==0)
        {
            printf("wrong: not 2-fold CDS. ***this information is from update_best_2fold_sol()***\n");
            exit(0);
        }
        finish = clock();
        real_time = double(finish - start)/(double)CLOCKS_PER_SEC;
        printf("The best 2-fold solution has been updated, @@@@@@ best_count_2fold_num: %d best_2fold_value: %d\n",best_count_2fold_num,best_2fold_value);
    }
}
void grasp(int outter_step,int inner_step)
{
    int outter=0;
    best_value=INT_MAX;
    best_2fold_value = INT_MAX;
    while(outter<outter_step)
    {
        init();
        finish = clock();
        real_time = double(finish - start)/(double)CLOCKS_PER_SEC;
        if(real_time > time_limit) return;
        init_random();
        solution_neibor.clear();
        localsearch(inner_step);
        outter++;
        finish = clock();
        real_time = double(finish - start)/(double)CLOCKS_PER_SEC;
        if(real_time > time_limit) return;
    }
}
static std::chrono::steady_clock::time_point wd_t0;
double best_time_wall = -1.0;
static void wd_tick(std::string fname, int sd, double limit) {
    int last_best = INT_MAX;
    for (;;) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        double el = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - wd_t0).count();
        int b = best_2fold_value;
        if (b > 0 && b < last_best) { last_best = b; best_time_wall = el; }
        if (el >= limit) {
            printf("RESULT %s %d %d %.2f\n", fname.c_str(), sd, last_best,
                   best_time_wall >= 0.0 ? best_time_wall : el);
            fflush(NULL);
            _exit(0);
        }
    }
}
int main(int argc, char *argv[])
{
    char filename[200];
    if (argc >= 4) {
        strcpy(filename, argv[1]);
        seed = atoi(argv[2]);
        time_limit = atof(argv[3]);
    } else if (argc == 1) {
        strcpy(filename, "vibrobox.mtx");
        seed = 1000;
        time_limit = 600.0;
    } else {
        printf("Usage: %s <filename> <seed> <time_limit_seconds>\n", argv[0]);
        return 1;
    }
    build_instance_UDG(filename);
    wd_t0 = std::chrono::steady_clock::now();
    std::thread(wd_tick, std::string(filename), seed, time_limit).detach();
    start = clock();
    int outter_step = 100000;
    int inner_step = 1000000;
    srand(seed);
    connect_count=0;
    memset(vis,0,vertex_num*sizeof(int));
    check_graph_connect(2,100);
    if(connect_count!=vertex_num){
    	printf("ERROR: graph is not connected!\n");
    	return 1;
    }
    init();
    grasp(outter_step,inner_step);
    printf("RESULT %s %d %d %.2f\n", filename, seed, best_2fold_value, best_time_wall >= 0.0 ? best_time_wall : real_time);
    free_all();
    return 0;
}
